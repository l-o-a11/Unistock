import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Login from "../features/auth/pages/LoginPage.jsx";
import AppLayout from "../layout/AppLayout.jsx";
import PrivateRoute from "../features/shared/PrivateRoute.jsx";

import DashboardPage from "../features/dashboard/dashboard.jsx";

import RolesPage from "../features/roles/pages/RolesPage";
import CreateRolPage from "../features/roles/pages/CreateRolPage.jsx";
import EditRolPage from "../features/roles/pages/EditRolPage.jsx";

import SuppliesPage from "../features/supplies/pages/SuppliesPage.jsx";

import ProductCategoriesPage from "../features/productCategories/pages/ProductCategoriesPage.jsx";
import CategoriesSupplyPage from "../features/categoriesSupply/pages/CategoriesSupplyPage.jsx";

import ProductsPage from "../features/products/pages/ProductsPage.jsx";

import SuppliersPage from "../features/suppliers/pages/SuppliersPage.jsx";

import ShoppingsPage from "../features/shopping/pages/ShoppingsPage.jsx";

import ThirdPartiesPage from "../features/third_parties/pages/Third_partiesPage.jsx";

import UsersPage from "../features/users/pages/UsersPage.jsx";

import ProductionsPage from "../features/production/pages/ProductionPage.jsx";
import ProductionDetailsPage from "../features/production/productionDetails/pages/ProductionDetailsPage.jsx";
import ProductionCalendarPage from "../features/production/pages/ProductionCalendarPage.jsx";
import EmployeesPage from "../features/employees/pages/EmployeesPage.jsx";

import ProfilePage from "../features/auth/pages/ProfilePage.jsx";

import SedesPage from "../features/sedes/pages/sedesPage.jsx";

export function RouterApp() {
  return (
    <Routes>

      <Route path="/" element={<Login />} />

      <Route path="/layout" element={
        <PrivateRoute>
          <AppLayout />
        </PrivateRoute>
      }>
        <Route index element={
          <PrivateRoute modulo="dashboard"><DashboardPage /></PrivateRoute>
        } />
        <Route path="dashboard" element={
          <PrivateRoute modulo="dashboard"><DashboardPage /></PrivateRoute>
        } />

        <Route path="usuarios" element={
          <PrivateRoute modulo="usuarios"><UsersPage /></PrivateRoute>
        } />

        <Route path="roles" element={
          <PrivateRoute modulo="roles"><RolesPage /></PrivateRoute>
        } />
        <Route path="roles/crear" element={
          <PrivateRoute modulo="roles"><CreateRolPage /></PrivateRoute>
        } />
        <Route path="roles/editar/:id" element={
          <PrivateRoute modulo="roles"><EditRolPage /></PrivateRoute>
        } />

        <Route path="sedes" element={
          <PrivateRoute modulo="sedes"><SedesPage /></PrivateRoute>
        } />

        <Route path="insumos" element={
          <PrivateRoute modulo="insumos"><SuppliesPage /></PrivateRoute>
        } />
        <Route path="categorias-insumos" element={
          <PrivateRoute modulo="categorias de insumos"><CategoriesSupplyPage /></PrivateRoute>
        } />

        <Route path="proveedores" element={
          <PrivateRoute modulo="proveedores"><SuppliersPage /></PrivateRoute>
        } />

        <Route path="compras" element={
          <PrivateRoute modulo="compras"><ShoppingsPage /></PrivateRoute>
        } />

        <Route path="productos" element={
          <PrivateRoute modulo="productos"><ProductsPage /></PrivateRoute>
        } />
        <Route path="categorias-productos" element={
          <PrivateRoute modulo="categorias de productos"><ProductCategoriesPage /></PrivateRoute>
        } />
        <Route path="productos/crear" element={
          <PrivateRoute modulo="productos"><ProductsPage /></PrivateRoute>
        } />
        <Route path="productos/editar/:id" element={
          <PrivateRoute modulo="productos"><ProductsPage /></PrivateRoute>
        } />

        <Route path="produccion" element={
          <PrivateRoute modulo="produccion"><ProductionsPage /></PrivateRoute>
        } />
        <Route path="produccion/detalle/:id" element={
          <PrivateRoute modulo="produccion"><ProductionDetailsPage /></PrivateRoute>
        } />
        <Route path="/layout/produccion/calendario" element={
          <PrivateRoute modulo="produccion"><ProductionCalendarPage /></PrivateRoute>
        } />

        <Route path="terceros" element={
          <PrivateRoute modulo="terceros"><ThirdPartiesPage /></PrivateRoute>
        } />

        <Route path="empleados" element={
          <PrivateRoute modulo="empleados"><EmployeesPage /></PrivateRoute>
        } />

        <Route path="perfil" element={<ProfilePage />} />

      </Route>

      <Route path="*" element={<Navigate to="/layout" replace />} />

    </Routes>
  );
}

export default RouterApp;