import httpClient, { httpRequest } from "../../shared/utils/httpClient";
import { Categories } from "../types/constants";
import { productCategoryAPI } from "../../productCategories/services/productCategoryAPI";

const PRODUCT_ENDPOINTS = ["/products"];
const PRODUCT_CATEGORY_ENDPOINTS = ["/product-categories", "/products-categories"];
const TECHNICAL_SHEET_ENDPOINTS = {
  list: (productId) => `/products/${productId}/tecnicas`,
  get: (productId, sheetId) => `/products/${productId}/tecnicas/${sheetId}`,
  create: (productId) => `/products/${productId}/tecnicas`,
  delete: (productId, sheetId) => `/products/${productId}/tecnicas/${sheetId}`,
};

const unwrapResponse = (response) => {
  if (!response) return response;

  return (
    response.products ??
    response.product ??
    response.productos ??
    response.producto ??
    response.technical_sheets ??
    response.technicalSheets ??
    response.tecnicas ??
    response.fichasTecnicas ??
    response.categories ??
    response.categorias ??
    response.data?.products ??
    response.data?.product ??
    response.data?.productos ??
    response.data?.producto ??
    response.data?.technical_sheets ??
    response.data?.technicalSheets ??
    response.data?.tecnicas ??
    response.data?.fichasTecnicas ??
    response.data?.categories ??
    response.data?.categorias ??
    response.data?.data ??
    response.data ??
    response
  );
};

const asArray = (response) => {
  const data = unwrapResponse(response);
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.products)) return data.products;
  if (Array.isArray(data?.productos)) return data.productos;
  if (Array.isArray(data?.technical_sheets)) return data.technical_sheets;
  if (Array.isArray(data?.technicalSheets)) return data.technicalSheets;
  if (Array.isArray(data?.tecnicas)) return data.tecnicas;
  if (Array.isArray(data?.fichasTecnicas)) return data.fichasTecnicas;
  if (data?.ficha_tecnica) return [data.ficha_tecnica];
  if (data?.technicalSheet) return [data.technicalSheet];
  if (data?.fichaTecnica) return [data.fichaTecnica];
  if (data && typeof data === 'object') return [data];
  return [];
};

const requestEndpointFallback = async (endpoints, options = {}) => {
  let lastError;

  for (const endpoint of endpoints) {
    try {
      return await httpRequest(endpoint, options);
    } catch (error) {
      lastError = error;
      if (![404, 400, 422].includes(error?.status)) {
        throw error;
      }
    }
  }

  throw lastError;
};

const sendWithPayloadFallback = async (endpoint, method, payloads) => {
  let lastError;

  for (const payload of payloads) {
    try {
      return await httpRequest(endpoint, { method, body: payload });
    } catch (error) {
      lastError = error;
      if (![400, 422].includes(error?.status)) {
        throw error;
      }
    }
  }

  throw lastError;
};

const toDateString = (value) => {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date.toISOString().split("T")[0];
};

const categoryNameFromId = (categoryId, categories = []) => {
  const category = categories.find((cat) => String(cat.id ?? cat._id) === String(categoryId));
  return (
    category?.name ??
    category?.nombre ??
    Categories.find((cat) => String(cat.id) === String(categoryId))?.name ??
    "General"
  );
};

const toUiProduct = (raw, categories = []) => {
  if (!raw) return raw;
  const categoryId =
    raw.id_categorias ??
    raw.id_categoria ??
    raw.idCategoria ??
    raw.categoryId ??
    raw.category_id ??
    raw.categoria_id ??
    raw.idCategory;
  const image = raw.image ?? raw.imagenes_Url?.[0] ?? raw.imagenesUrl?.[0] ?? null;

  return {
    id: raw.id ?? raw._id,
    _id: raw._id,
    id_categorias: categoryId,
    id_categoria: categoryId,
    categoryId,
    sedeId: raw.sedeId ?? raw.sede ?? raw.id_sede ?? null,
    image,
    reference: raw.reference ?? raw.referencia ?? "",
    name: raw.name ?? raw.nombre ?? "",
    category:
      raw.category?.name ??
      raw.category?.nombre ??
      raw.category ??
      raw.nombreCategoria ??
      categoryNameFromId(categoryId, categories),
    price: raw.price ?? raw.precio ?? 0,
    stock: raw.stock ?? 0,
    active: raw.active ?? raw.estado ?? raw.activo ?? true,
    technicalSheetVersions: raw.technicalSheetVersions ?? raw.versiones ?? 0,
    lastVersionDate: raw.lastVersionDate ?? toDateString(raw.updatedAt ?? raw.createdAt),
    technicalSheet: raw.technicalSheet ?? null,
  };
};

const hasValue = (value) => {
  if (Array.isArray(value)) return value.some(hasValue);
  if (value && typeof value === "object") return Object.values(value).some(hasValue);
  return value !== null && value !== undefined && String(value).trim() !== "";
};

const sheetItemsToMaterials = (sheetData = {}) => {
  const materials = [];

  (sheetData.fabrics || []).forEach((item, index) => {
    if (hasValue(item)) {
      materials.push({
        nombre: item.name || `Tela ${index + 1}`,
        unidad: item.talla ? `Talla ${item.talla}` : "",
        cantidades: item.consumption || item.pieces || item.talla || "1",
        observaciones: [item.consumption && `Consumo: ${item.consumption}`, item.pieces && `Piezas: ${item.pieces}`].filter(Boolean).join(" | "),
      });
    }
  });

  [...(sheetData.cups || []), ...(sheetData.closures || []), ...(sheetData.accessories || []), ...(sheetData.measurements || [])]
    .forEach((item) => {
      if (hasValue(item)) {
        materials.push({
          nombre: item.name || item.type || "Material ficha tecnica",
          unidad: "",
          cantidades: (item.values || []).filter((value) => String(value || "").trim()).join(", ") || "1",
          observaciones: "",
        });
      }
    });

  return materials;
};

const toUiSheet = (raw) => {
  if (!raw) return raw;
  const responsable = raw.responsable ?? raw.createdBy ?? raw.client ?? "Sin responsable";
  return {
    id: raw.id ?? raw._id,
    productId: raw.productId ?? raw.id_producto ?? raw.id_productos,
    version: raw.version ?? raw.versiones ?? 1,
    date: toDateString(raw.createdAt ?? raw.date ?? raw.fecha_inicio) ?? new Date().toISOString().split("T")[0],
    responsable,
    client: raw.client ?? responsable,
    ref: raw.ref ?? raw.reference ?? "",
    type: raw.type ?? "",
    description: raw.description ?? raw.descripcion ?? raw.descripciones ?? "",
    descripciones: raw.descripciones ?? raw.description ?? raw.descripcion ?? "",
    observations: raw.observations ?? raw.observaciones ?? "",
    createdBy: raw.createdBy ?? responsable,
    image: raw.image ?? raw.imagen ?? null,
    fabrics: raw.fabrics ?? [],
    cups: raw.cups ?? [],
    closures: raw.closures ?? [],
    accessories: raw.accessories ?? [],
    measurements: raw.measurements ?? [],
  };
};

const getCategories = async () => {
  try {
    const categories = await productCategoryAPI.getAll();
    return Array.isArray(categories) && categories.length > 0 ? categories : Categories;
  } catch {
    return Categories;
  }
};

const resolveCategoryId = async (productData) => {
  const explicitId =
    productData.categoryId ??
    productData.id_categorias ??
    productData.id_categoria ??
    productData.idCategoria;

  if (explicitId) {
    return explicitId;
  }

  const categories = await getCategories();

  const byName = categories.find((cat) => {
    const name = cat.name ?? cat.nombre;

    return (
      name &&
      productData.category &&
      name.toLowerCase().trim() ===
      productData.category.toLowerCase().trim()
    );
  });

  const resolvedId = byName?.id ?? byName?._id;

  if (!resolvedId) {
    throw new Error(
      "Selecciona una categoria registrada antes de guardar el producto"
    );
  }

  return resolvedId;
};

const buildProductPayloads = async (productData) => {
  const categoryId = await resolveCategoryId(productData);
  const image = productData.image ? [productData.image] : [];
  const reference = productData.reference ?? productData.referencia;
  const name = productData.name ?? productData.nombre;
  const price = Number(productData.price ?? productData.precio);
  const stock = Number(productData.stock);
  const sedeId = productData.sedeId ?? productData.sede ?? null;

  return [
    {
      id_categorias: categoryId,
      sedeId,
      imagenes_Url: image,
      referencia: reference,
      nombre: name,
      precio: price,
      stock,
    },
    {
      id_categoria: categoryId,
      sedeId,
      imagenes_Url: image,
      referencia: reference,
      nombre: name,
      precio: price,
      stock,
    },
    {
      categoryId,
      sedeId,
      image: productData.image ?? null,
      reference,
      name,
      price,
      stock,
    },
  ];
};

const buildProductCreatePayloads = async (productData) => {
  const productPayloads = await buildProductPayloads(productData);
  const sheet = productData.technicalSheet;
  const date = sheet?.date || new Date().toISOString().split("T")[0];
  const responsible = sheet?.createdBy || sheet?.client || "Sin responsable";
  const description = sheet?.description || sheet?.observations || "Ficha tecnica";
  const materials = sheetItemsToMaterials(sheet);

  return productPayloads.map((payload) => ({
    ...payload,
    ficha_tecnica: {
      responsable: responsible,
      fecha_inicio: date,
      fecha_fin: date,
      versiones: Number(sheet?.version || 1),
      descripciones: description,
      client: sheet?.client || "",
      ref: sheet?.ref || payload.referencia || payload.reference || "",
      type: sheet?.type || "",
      description,
      observations: sheet?.observations || "",
      createdBy: responsible,
      image: sheet?.image || null,
      fabrics: sheet?.fabrics || [],
      cups: sheet?.cups || [],
      closures: sheet?.closures || [],
      accessories: sheet?.accessories || [],
      measurements: sheet?.measurements || [],
      materiales: materials,
    },
  }));
};

const buildTechnicalSheetPayloads = (productId, sheetData = {}) => {
  // Ignorar el campo raw para no mezclar datos viejos con nuevos
  const { raw: _raw, ...cleanSheetData } = sheetData;
  sheetData = cleanSheetData;
  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  const date = toDateString(sheetData.date) || todayStr;
  const version = Number(sheetData.version ?? 1);
  // Usar || en vez de ?? para que string vacío "" también active el fallback
  const description = sheetData.description || sheetData.descripciones || sheetData.descripcion || sheetData.observations || "";
  const responsible = sheetData.createdBy || sheetData.client || sheetData.responsable || sheetData.responsible || "Sin responsable";

  const materials = sheetItemsToMaterials(sheetData);

  return [
    {
      id_producto: productId,
      responsable: responsible,
      fecha_inicio: date,
      fecha_fin: date,
      versiones: version,
      descripciones: description,
      client: sheetData.client ?? "",
      ref: sheetData.ref ?? "",
      type: sheetData.type ?? "",
      description: sheetData.description || "",
      observations: sheetData.observations ?? "",
      createdBy: sheetData.createdBy ?? "",
      image: sheetData.image ?? null,
      fabrics: sheetData.fabrics ?? [],
      cups: sheetData.cups ?? [],
      closures: sheetData.closures ?? [],
      accessories: sheetData.accessories ?? [],
      measurements: sheetData.measurements ?? [],
      materiales: materials,
    },
    {
      productId,
      version,
      date,
      client: sheetData.client ?? responsible,
      type: sheetData.type ?? "Ficha tecnica",
      description,
      fabrics: sheetData.fabrics ?? [],
      cups: sheetData.cups ?? [],
      closures: sheetData.closures ?? [],
      accessories: sheetData.accessories ?? [],
      observations: sheetData.observations ?? "",
      createdBy: responsible,
      image: sheetData.image ?? null,
      materials,
    },
  ];
};

const getTechnicalSheetEndpoints = (productId) => [TECHNICAL_SHEET_ENDPOINTS.list(productId)];

export const productAPI = {
  getAll: async () => {
    const categories = await getCategories();
    const response = await requestEndpointFallback(PRODUCT_ENDPOINTS, { method: "GET" });
    const products = asArray(response).map((product) => toUiProduct(product, categories));

    return Promise.all(
      products.map(async (product) => {
        try {
          const versions = await productAPI.getTechnicalSheetVersions(product.id);
          const sorted = [...versions].sort((a, b) => (b.version ?? 0) - (a.version ?? 0));
          return {
            ...product,
            technicalSheet: sorted[0] ?? null,
            technicalSheetVersions: sorted.length || product.technicalSheetVersions,
            lastVersionDate: sorted[0]?.date ?? product.lastVersionDate,
          };
        } catch {
          return product;
        }
      })
    );
  },

  getSummaries: async () => {
    const categories = await getCategories();
    const response = await requestEndpointFallback(PRODUCT_ENDPOINTS, { method: "GET" });
    return asArray(response).map((product) => toUiProduct(product, categories));
  },

  getByReference: async (referencia) => {
    if (!referencia) return null;
    const categories = await getCategories();
    const response = await requestEndpointFallback(
      PRODUCT_ENDPOINTS.map((endpoint) => `${endpoint}?search=${encodeURIComponent(String(referencia))}&limit=1`),
      { method: "GET" }
    );
    const products = asArray(response);
    const product = products.find((p) =>
      String(p.referencia || p.reference || p.id || p._id || "").trim() === String(referencia).trim()
    ) || products[0];
    if (!product) return null;
    return toUiProduct(product, categories);
  },

  getById: async (id) => {
    // ✅ Fix: nunca llamar /products/undefined (evita el 404 de GET /api/products/undefined)
    if (!id) return null;
    const categories = await getCategories();
    const response = await requestEndpointFallback(PRODUCT_ENDPOINTS.map((endpoint) => `${endpoint}/${id}`), { method: "GET" });
    const product = toUiProduct(unwrapResponse(response), categories);
    const versions = await productAPI.getTechnicalSheetVersions(product.id).catch(() => []);
    const sorted = [...versions].sort((a, b) => (b.version ?? 0) - (a.version ?? 0));

    return {
      ...product,
      technicalSheet: sorted[0] ?? null,
      technicalSheetVersions: sorted.length || product.technicalSheetVersions,
      lastVersionDate: sorted[0]?.date ?? product.lastVersionDate,
    };
  },

create: async (productData) => {
    const payloads = await buildProductCreatePayloads(productData);
    const response = await sendWithPayloadFallback(PRODUCT_ENDPOINTS[0], "POST", payloads);
// ✅ Usar la respuesta cruda para leer product y ficha_tecnica juntos.
    // La API nueva (Api_Unistock) envuelve la respuesta en { success, data: { product, ficha_tecnica } }.
    // NUNCA unwrapResponse aquí: unwrapResponse devuelve `product` (el primer truthy),
    // perdiendo la ficha. Además, hay que leer `response.data.product` (no `response.product`),
    // porque el objeto `data` de la API contiene { product, ficha_tecnica }.
    const data = response?.data ?? response ?? {};
    const productRaw = data.product || data;
    const created = toUiProduct(productRaw, await getCategories());
    const createdSheet = data.ficha_tecnica || data.technicalSheet || data.fichaTecnica;

    if (createdSheet) {
      created.technicalSheet = toUiSheet(createdSheet);
      created.technicalSheetVersions = 1;
      created.lastVersionDate = created.technicalSheet?.date ?? created.lastVersionDate;
    }

    // ✅ Si el backend no procesó la ficha técnica, crearla por separado
    if (!created.technicalSheet && productData.technicalSheet && created.id) {
      try {
        const sheet = await productAPI.createTechnicalSheet({
          ...productData.technicalSheet,
          productId: created.id,
          version: 1,
        });
        created.technicalSheet = sheet;
        created.technicalSheetVersions = 1;
        created.lastVersionDate = sheet?.date ?? created.lastVersionDate;
      } catch {
        // No bloquear si falla la ficha
      }
    }

    return created;
  },

  update: async (id, updatedData) => {
    const { technicalSheet } = updatedData || {};
    const payloads = await buildProductPayloads(updatedData);
    const response = await sendWithPayloadFallback(`${PRODUCT_ENDPOINTS[0]}/${id}`, "PUT", payloads);
    const updated = toUiProduct(unwrapResponse(response), await getCategories());

    if (technicalSheet) {
      const updatedSheet = await productAPI.updateTechnicalSheet(id, technicalSheet);
      updated.technicalSheet = updatedSheet;
      updated.technicalSheetVersions = updatedSheet?.version ?? updated.technicalSheetVersions ?? 1;
      updated.lastVersionDate = updatedSheet?.date ?? updated.lastVersionDate;
    }

    return updated;
  },

  delete: async (id) => {
    const response = await httpClient.delete(`${PRODUCT_ENDPOINTS[0]}/${id}`);
    return unwrapResponse(response);
  },

  toggleActive: async (id, nextActive) => {
    const patchEndpoints = [
      `${PRODUCT_ENDPOINTS[0]}/${id}/status`,
      `${PRODUCT_ENDPOINTS[0]}/${id}/toggle-active`,
    ];

    try {
      const response = await requestEndpointFallback(patchEndpoints, {
        method: "PATCH",
        body: {},
      });
      return toUiProduct(unwrapResponse(response), await getCategories());
    } catch (error) {
      if (error?.status !== 404 || typeof nextActive !== "boolean") {
        throw error;
      }

      const response = await httpRequest(`${PRODUCT_ENDPOINTS[0]}/${id}`, {
        method: "PUT",
        body: {
          estado: nextActive,
          active: nextActive,
        },
      });

      return toUiProduct(unwrapResponse(response), await getCategories());
    }
  },

  getTechnicalSheetVersions: async (productId) => {
    const response = await requestEndpointFallback(getTechnicalSheetEndpoints(productId), { method: "GET" });
    return asArray(response).map(toUiSheet);
  },

  getTechnicalSheetById: async (productId, sheetId) => {
    const response = await requestEndpointFallback(
      [TECHNICAL_SHEET_ENDPOINTS.get(productId, sheetId)],
      { method: "GET" }
    );
    return toUiSheet(unwrapResponse(response));
  },

  createTechnicalSheet: async (sheetData) => {
    const productId = sheetData.productId ?? sheetData.id_producto;
    const payloads = buildTechnicalSheetPayloads(productId, sheetData);
    const response = await sendWithPayloadFallback(
      TECHNICAL_SHEET_ENDPOINTS.create(productId),
      "POST",
      payloads
    );
    return toUiSheet(unwrapResponse(response));
  },

  updateTechnicalSheet: async (productId, sheetData) => {
    const versions = await productAPI.getTechnicalSheetVersions(productId).catch(() => []);
    const current = [...versions].sort((a, b) => (b.version ?? 0) - (a.version ?? 0))[0];
    const { raw: _raw, id: _id, ...cleanSheetData } = sheetData;
    return productAPI.createTechnicalSheet({
      ...cleanSheetData,
      productId,
      version: (current?.version ?? 0) + 1,
    });
  },

  deleteTechnicalSheet: async (productIdOrSheetId, maybeSheetId) => {
    const productId = maybeSheetId ? productIdOrSheetId : null;
    const sheetId = maybeSheetId ?? productIdOrSheetId;

    if (!productId) {
      throw new Error("Para eliminar una ficha tecnica se requiere productId y sheetId");
    }

    const response = await requestEndpointFallback(
      [TECHNICAL_SHEET_ENDPOINTS.delete(productId, sheetId)],
      { method: "DELETE" }
    );
    return unwrapResponse(response);
  },
};