import { useState, useEffect, useCallback, useMemo } from 'react';
import { ProductionAPIClient } from '../production/services/ProductionAPIClient';
import { sedesAPI } from '../sedes/services/sedesAPI';
import { supplyAPI } from '../supplies/services/supplyAPI';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
// ⚠️ Ajusta esta ruta si la ubicación real de este archivo dentro de
// `features/` tiene otra profundidad (debe apuntar a shared/assets).
import putongasLogoUrl from '../shared/assets/putongasLogo.png';

// ── Constantes ─────────────────────────────────────────────────────
const MONTHS = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
const YEARS = [2022, 2023, 2024, 2025, 2026];

const BAR_PROCESSES = [
  'En espera', 'Tráfico entre sedes', 'Ficha técnica', 'Corte', 'Diseño',
  'En producción', 'Bodega', 'Mercadeo', 'Cancelado', 'Compras', 'Recepción',
];

// Mapeo estado backend → proceso barra
const ESTADO_TO_PROCESO = {
  'En espera': 'En espera', 'Diseño': 'Diseño',
  'Ficha Técnica': 'Ficha técnica', 'Ficha tecnica': 'Ficha técnica',
  'Corte': 'Corte', 'Producción': 'En producción', 'En producción': 'En producción',
  'Compras': 'Compras', 'Empaque': 'Bodega', 'Enviado': 'Recepción',
  'Anulada': 'Cancelado', 'Tráfico entre sedes': 'Tráfico entre sedes',
  'Mercadeo': 'Mercadeo',
};

// ✅ El backend guarda el estado "en producción" con dos nombres distintos
// según la ruta que lo creó ('Producción' y 'En producción' — ver el
// mapeo de arriba). Los cálculos de stats deben reconocer ambas variantes,
// o subcuentan (y por eso "Producciones actuales" quedaba en 0/"—").
const ESTADOS_EN_PRODUCCION = ['Producción', 'En producción'];

const barIcons = {
  'En espera': 'M12 2a10 10 0 1 0 4.95 18.66M12 6v6l3 1.5',
  'Tráfico entre sedes': 'M1 3h15v13H1zM16 8h4l3 3v5h-7V8zM5.5 19a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zm13 0a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z',
  'Ficha técnica': 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M16 13H8M16 17H8',
  'Corte': 'M6 3a3 3 0 1 0 0 6 3 3 0 0 0 0-6zm0 12a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM20 4 8.12 15.88M14.47 14.48 20 20M8.12 8.12 12 12',
  'Diseño': 'M12 19l7-7 3 3-7 7-3-3zM18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z',
  'En producción': 'M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16zM3.27 6.96 12 12.01l8.73-5.05M12 22.08V12',
  'Bodega': 'M2 20h20M4 20V10l8-6 8 6v10M10 20v-6h4v6',
  'Mercadeo': 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM9 22V12h6v10',
  'Cancelado': 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM15 9l-6 6M9 9l6 6',
  'Compras': 'M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0',
  'Recepción': 'M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15',
};
const barIconKeys = Object.keys(barIcons);

const SEDE_COLORS = ['#e040b8', '#f0a0d8', '#a78bfa', '#34d399', '#f59e0b', '#60a5fa'];

// ── Helpers ────────────────────────────────────────────────────────
const sameMonthYear = (val, m, y) => {
  if (!val) return false;
  const d = new Date(val);
  return d.getMonth() === m && d.getFullYear() === y;
};

// Fecha de referencia de una orden para agrupar por período
// Prioridad: fecha de la última transición de estado → updatedAt → createdAt
const orderDate = (o) => {
  const last = (o.historial || []).slice(-1)[0];
  return last?.fecha || o.updatedAt || o.createdAt || null;
};

// Suma de productos (detalles.cantidad) de una orden
const totalProductos = (o) =>
  (o.detalles || []).reduce((s, d) => s + (Number(d.cantidad) || 0), 0);

const calcAvgDays = (orders) => {
  const done = orders.filter(o => o.estado === 'Enviado');
  if (!done.length) return null;

  const getStart = (o) => {
    const primera = (o.historial || [])[0];
    return o.createdAt || primera?.fecha || o.updatedAt || null;
  };
  const getEnd = (o) => {
    const h = (o.historial || []).find(hh => hh.estado === 'Enviado');
    const ultima = (o.historial || []).slice(-1)[0];
    return h?.fecha || o.updatedAt || ultima?.fecha || o.createdAt || null;
  };

  let sum = 0;
  let validCount = 0;
  const invalidSamples = [];

  done.forEach((o) => {
    const startRaw = getStart(o);
    const endRaw = getEnd(o);
    const start = startRaw ? new Date(startRaw).getTime() : NaN;
    const end = endRaw ? new Date(endRaw).getTime() : NaN;

    if (Number.isNaN(start) || Number.isNaN(end)) {
      if (invalidSamples.length < 3) {
        invalidSamples.push({ id: o.id || o._id, orderNumber: o.orderNumber, createdAt: o.createdAt, updatedAt: o.updatedAt, historial: o.historial });
      }
      return;
    }
    sum += Math.max(0, Math.round((end - start) / 86400000));
    validCount++;
  });

  if (!validCount) {
    if (invalidSamples.length) {
      console.warn('[Dashboard] Tiempo promedio: ninguna orden "Enviado" tiene fechas válidas. Ejemplos:', invalidSamples);
    }
    return null;
  }
  return Math.round(sum / validCount);
};

// Función universal de coincidencia por período (solo modos fijos: Día, Semana, Mes, Año)
const matchPeriod = (val, mode, monthIdx, year) => {
  if (!val) return false;
  const d = new Date(val);
  const now = new Date();
  if (mode === 'Día') return d.toDateString() === now.toDateString();
  if (mode === 'Semana') {
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - (now.getDay() === 0 ? 6 : now.getDay() - 1));
    startOfWeek.setHours(0, 0, 0, 0);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);
    return d >= startOfWeek && d <= endOfWeek;
  }
  if (mode === 'Mes') return d.getMonth() === monthIdx && d.getFullYear() === year;
  if (mode === 'Año') return d.getFullYear() === year;
  return true;
};

// ══════════════════════════════════════════════════════════════════════
// Gráficos para el reporte Excel
// ExcelJS no soporta gráficos nativos de Excel (no hay API de charts en
// la librería), así que renderizamos gráficos limpios a PNG usando
// <canvas> y los incrustamos como imágenes junto a sus tablas de datos
// (para que las cifras sigan siendo auditables/copiables). Esto es lo
// que le da al reporte una lectura "ejecutiva" en vez de solo filas y
// columnas de números.
// ══════════════════════════════════════════════════════════════════════
const roundRectPath = (ctx, x, y, w, h, r) => {
  const rr = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.arcTo(x + w, y, x + w, y + rr, rr);
  ctx.lineTo(x + w, y + h);
  ctx.lineTo(x, y + h);
  ctx.lineTo(x, y + rr);
  ctx.arcTo(x, y, x + rr, y, rr);
  ctx.closePath();
};

const canvasToPngBase64 = (canvas) => canvas.toDataURL('image/png').split(',')[1];

// scale=3 → PNG a resolución ~3x para que se vea nítido incluso si el
// usuario lo agranda en Excel o lo imprime.
const makeChartCanvas = (width, height, scale = 3) => {
  const canvas = document.createElement('canvas');
  canvas.width = width * scale;
  canvas.height = height * scale;
  const ctx = canvas.getContext('2d');
  ctx.scale(scale, scale);
  if (ctx.imageSmoothingEnabled !== undefined) ctx.imageSmoothingEnabled = true;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  return { canvas, ctx };
};

/** Convierte un color hex '#rrggbb' a 'rgba(r,g,b,a)'. */
const hexToRgba = (hex, alpha = 1) => {
  const h = hex.replace('#', '');
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
};

/** Panel de fondo redondeado detrás del área de trazado, para look "tarjeta". */
const drawPlotPanel = (ctx, x, y, w, h) => {
  ctx.fillStyle = '#FFFBFE';
  roundRectPath(ctx, x, y, w, h, 10);
  ctx.fill();
  ctx.strokeStyle = '#F3D9F3';
  ctx.lineWidth = 1;
  roundRectPath(ctx, x, y, w, h, 10);
  ctx.stroke();
};

/** Gráfico de barras verticales de una sola serie (procesos, comparativas). */
const drawBarChartPng = ({ width = 720, height = 300, categories, values, colorFor, title, yLabel = 'Cantidad' }) => {
  const { canvas, ctx } = makeChartCanvas(width, height);
  const longLabels = categories.some(c => String(c).length > 9);
  const padL = 46, padR = 20, padT = 44, padB = longLabels ? 78 : 44;
  const chartW = width - padL - padR;
  const chartH = height - padT - padB;
  const maxVal = Math.max(1, ...values);
  const niceMax = Math.ceil((maxVal * 1.15) / 5) * 5 || 5;

  drawPlotPanel(ctx, padL - 14, padT - 14, chartW + 28, chartH + 28);

  ctx.fillStyle = '#1a1a2e';
  ctx.font = '700 15px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(title, padL - 14, 22);

  const steps = 5;
  ctx.font = '10px Arial';
  for (let i = 0; i <= steps; i++) {
    const v = Math.round((niceMax / steps) * i);
    const y = padT + chartH - (v / niceMax) * chartH;
    ctx.strokeStyle = i === 0 ? '#E4B9E4' : '#F3E0F3';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + chartW, y); ctx.stroke();
    ctx.fillStyle = '#6b7280';
    ctx.textAlign = 'right';
    ctx.fillText(String(v), padL - 8, y + 3);
  }

  ctx.save();
  ctx.translate(15, padT + chartH / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#d946ef';
  ctx.font = '700 10px Arial';
  ctx.fillText(yLabel, 0, 0);
  ctx.restore();

  const n = categories.length;
  const slot = chartW / n;
  const barW = slot * 0.56;
  categories.forEach((cat, i) => {
    const v = values[i] || 0;
    const barH = (v / niceMax) * chartH;
    const x = padL + i * slot + (slot - barW) / 2;
    const y = padT + chartH - barH;
    const color = colorFor ? colorFor(v, i) : '#c084fc';

    // sombra suave debajo de la barra
    ctx.fillStyle = 'rgba(17,17,17,0.08)';
    roundRectPath(ctx, x + 1.5, y + 2, barW, Math.max(barH, 1), 4);
    ctx.fill();

    // barra con degradado vertical (más viva arriba, ligeramente más
    // oscura abajo) para dar volumen sin verse plana
    const grad = ctx.createLinearGradient(0, y, 0, y + Math.max(barH, 1));
    grad.addColorStop(0, hexToRgba(color, 1));
    grad.addColorStop(1, hexToRgba(color, 0.82));
    ctx.fillStyle = grad;
    roundRectPath(ctx, x, y, barW, Math.max(barH, 1), 4);
    ctx.fill();

    ctx.fillStyle = '#374151';
    ctx.font = '700 10.5px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(String(v), x + barW / 2, y - 6);

    ctx.save();
    ctx.translate(x + barW / 2, padT + chartH + 14);
    ctx.fillStyle = '#4b5563';
    ctx.font = '9.5px Arial';
    if (longLabels) { ctx.rotate(-Math.PI / 5); ctx.textAlign = 'right'; }
    else { ctx.textAlign = 'center'; }
    ctx.fillText(cat, 0, 0);
    ctx.restore();
  });

  ctx.strokeStyle = '#c9a0c9';
  ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(padL, padT + chartH); ctx.lineTo(padL + chartW, padT + chartH); ctx.stroke();

  return canvasToPngBase64(canvas);
};

/** Gráfico de líneas multi-serie (productos asignados a las sedes en el tiempo). */
const drawLineChartPng = ({ width = 720, height = 320, labels, series, title, yLabel = 'Unidades' }) => {
  const { canvas, ctx } = makeChartCanvas(width, height);
  const padL = 46, padR = 18, padT = 44, padB = 60;
  const chartW = width - padL - padR;
  const chartH = height - padT - padB;
  const allValues = series.flatMap(s => s.values);
  const maxVal = Math.max(1, ...(allValues.length ? allValues : [0]));
  const niceMax = Math.ceil((maxVal * 1.15) / 5) * 5 || 5;

  drawPlotPanel(ctx, padL - 14, padT - 14, chartW + 28, chartH + 28);

  ctx.fillStyle = '#1a1a2e';
  ctx.font = '700 15px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(title, padL - 14, 22);

  const steps = 5;
  ctx.font = '10px Arial';
  for (let i = 0; i <= steps; i++) {
    const v = Math.round((niceMax / steps) * i);
    const y = padT + chartH - (v / niceMax) * chartH;
    ctx.strokeStyle = i === 0 ? '#E4B9E4' : '#F3E0F3';
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + chartW, y); ctx.stroke();
    ctx.fillStyle = '#6b7280';
    ctx.textAlign = 'right';
    ctx.fillText(String(v), padL - 8, y + 3);
  }

  ctx.save();
  ctx.translate(15, padT + chartH / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#d946ef';
  ctx.font = '700 10px Arial';
  ctx.fillText(yLabel, 0, 0);
  ctx.restore();

  const n = labels.length;
  const stepX = n > 1 ? chartW / (n - 1) : 0;
  const xAt = (i) => padL + (n > 1 ? i * stepX : chartW / 2);
  const yAt = (v) => padT + chartH - (v / niceMax) * chartH;

  // Área suave bajo cada línea (da profundidad sin saturar el gráfico)
  series.forEach(s => {
    if (!s.values.length) return;
    ctx.beginPath();
    ctx.moveTo(xAt(0), padT + chartH);
    s.values.forEach((v, i) => ctx.lineTo(xAt(i), yAt(v)));
    ctx.lineTo(xAt(s.values.length - 1), padT + chartH);
    ctx.closePath();
    ctx.fillStyle = hexToRgba(s.color, 0.08);
    ctx.fill();
  });

  // Líneas + puntos con borde blanco (efecto "pop")
  series.forEach(s => {
    ctx.strokeStyle = s.color;
    ctx.lineWidth = 2.4;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    s.values.forEach((v, i) => {
      const x = xAt(i), y = yAt(v);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();
    s.values.forEach((v, i) => {
      const x = xAt(i), y = yAt(v);
      ctx.beginPath(); ctx.arc(x, y, 3.4, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff'; ctx.fill();
      ctx.beginPath(); ctx.arc(x, y, 3.4, 0, Math.PI * 2);
      ctx.lineWidth = 1.8; ctx.strokeStyle = s.color; ctx.stroke();
    });
  });

  ctx.fillStyle = '#4b5563';
  ctx.font = '9.5px Arial';
  ctx.textAlign = 'center';
  labels.forEach((lab, i) => {
    ctx.fillText(lab, xAt(i), padT + chartH + 16);
  });

  ctx.strokeStyle = '#c9a0c9';
  ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.moveTo(padL, padT + chartH); ctx.lineTo(padL + chartW, padT + chartH); ctx.stroke();

  // Leyenda con "chips" redondeados
  let lx = padL;
  const ly = padT + chartH + 34;
  ctx.font = '600 10px Arial';
  series.forEach(s => {
    ctx.fillStyle = s.color;
    roundRectPath(ctx, lx, ly - 8, 10, 10, 3);
    ctx.fill();
    ctx.fillStyle = '#374151';
    ctx.textAlign = 'left';
    ctx.fillText(s.name, lx + 14, ly);
    lx += ctx.measureText(s.name).width + 34;
  });

  return canvasToPngBase64(canvas);
};

// ── Componentes base ───────────────────────────────────────────────
const Card = ({ children, className = '' }) => (
  <div className={`bg-white rounded-2xl p-5 ${className}`} style={{ border: '1.5px solid #e5e7eb' }}>{children}</div>
);

function Dropdown({ value, options, onChange }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1 border border-pink-300 rounded-xl px-3 py-1 text-sm font-medium text-gray-800 bg-white">
        {value}
        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="6 9 12 15 18 9" /></svg>
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 bg-white border border-pink-300 rounded-2xl shadow z-50 py-1 min-w-full max-h-52 overflow-y-auto">
          {options.map(opt => (
            <div key={opt} onClick={() => { onChange(opt); setOpen(false); }}
              className={`px-4 py-2 text-sm cursor-pointer hover:bg-pink-50 ${String(opt) === String(value) ? 'text-fuchsia-600 font-semibold' : 'text-gray-700'}`}>
              {opt}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const BarTick = ({ x, y, payload }) => {
  const words = payload.value.split(' ');
  return (
    <g transform={`translate(${x},${y + 4})`}>
      {words.map((w, i) => <text key={i} x={0} dy={13 + i * 13} textAnchor="middle" fill="#4b5563" fontSize={10}>{w}</text>)}
    </g>
  );
};

// ── Dashboard ──────────────────────────────────────────────────────
export default function ProductionDashboard() {
  const [viewMode, setViewMode] = useState('Todas');
  const [timeView, setTimeView] = useState('Mes');
  const [selectedMonth, setSelectedMonth] = useState(MONTHS[new Date().getMonth()]);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [barTimeView, setBarTimeView] = useState('Año');

  // ── Modal de descarga con rango de fechas personalizado ──────────
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [modalDateFrom, setModalDateFrom] = useState('');
  const [modalDateTo, setModalDateTo] = useState('');
  const modalRangeError = !!(modalDateFrom && modalDateTo) && new Date(modalDateFrom) > new Date(modalDateTo);

  // Datos crudos del backend
  const [orders, setOrders] = useState([]);
  const [sedesNames, setSedesNames] = useState([]);
const [supplies, setSupplies] = useState({ almacenamiento: 0, stock: 0 });

  // ── Carga inicial + polling (solo datos crudos) ───────────────
  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const [ordersRaw, sedesResult, suppliesResult] = await Promise.all([
          ProductionAPIClient.getOrders({ limit: 1000 }),
          sedesAPI.getAll({ limit: 100, estado: true }),
          supplyAPI.getAll({ estado: true, limit: 1000 }),
        ]);
        if (!mounted) return;
        setOrders(Array.isArray(ordersRaw) ? ordersRaw : []);
        setSedesNames((sedesResult?.data || []).map(s => s.nombre).filter(Boolean));
        const allSupplies = Array.isArray(suppliesResult?.data) ? suppliesResult.data
          : Array.isArray(suppliesResult) ? suppliesResult : [];
setSupplies({
          almacenamiento: allSupplies.length,
          stock: allSupplies.reduce((sum, s) => sum + (Number(s.stock) || 0), 0),
        });
      } catch (e) { console.error('[Dashboard]', e); }
    };
    load();
    const id = setInterval(load, 10000);
    return () => { mounted = false; clearInterval(id); };
  }, []);

  // ── Stats: recalculados al cambiar período ────────────────────
  const monthIdx = MONTHS.indexOf(selectedMonth);

  const { stats, generalStatus } = useMemo(() => {
    if (!orders.length) return {
      stats: { current: 0, completedThisMonth: 0, pending: 0, avgTime: '—', periodLabel: '', avgPeriodLabel: '' },
      generalStatus: { delayed: 0, onTrack: 0 },
    };

    const nowMs = Date.now();

    // Etiqueta dinámica del período para el label de "Completadas"
    const periodLabel = timeView === 'Día' ? 'hoy'
      : timeView === 'Semana' ? 'esta semana'
        : timeView === 'Mes' ? `en ${selectedMonth}`
          : `en ${selectedYear}`;

    // Una orden activa pertenece al período si alguna fecha suya cae en él
    const inPeriodActive = (o) => {
      if (matchPeriod(o.updatedAt, timeView, monthIdx, selectedYear)) return true;
      if (matchPeriod(o.createdAt, timeView, monthIdx, selectedYear)) return true;
      return (o.historial || []).some(h => matchPeriod(h.fecha, timeView, monthIdx, selectedYear));
    };

    // ── Producciones actuales: estado "Producción" con actividad en el período ──
    const currentInPeriod = orders.filter(x => ESTADOS_EN_PRODUCCION.includes(x.estado) && inPeriodActive(x)).length;
    const currentTotal = orders.filter(x => ESTADOS_EN_PRODUCCION.includes(x.estado)).length;
    const current = currentInPeriod > 0 ? currentInPeriod : currentTotal;

    // ── Completadas en el período ──────────────────────────────────────────────
    const completedThisMonth = orders.filter(x => {
      if (x.estado !== 'Enviado') return false;
      const h = (x.historial || []).find(h => h.estado === 'Enviado');
      return matchPeriod(h?.fecha || x.updatedAt, timeView, monthIdx, selectedYear);
    }).length;

    // ── Por iniciar: Diseño o Ficha Técnica con actividad en el período ────────
    const pending = orders.filter(x =>
      x.estado && x.estado !== 'Anulada' &&
      ['Diseño', 'Ficha Técnica', 'Ficha tecnica'].includes(x.estado) &&
      inPeriodActive(x)
    ).length;

    // ── Tiempo promedio: período ANTERIOR al seleccionado ─────────────────────
    const prevDone = orders.filter(x => {
      if (x.estado !== 'Enviado') return false;
      const h = (x.historial || []).find(hh => hh.estado === 'Enviado');
      const d = h?.fecha || x.updatedAt;
      if (timeView === 'Año') return new Date(d || 0).getFullYear() === selectedYear - 1;
      const pm = monthIdx === 0 ? 11 : monthIdx - 1;
      const py = monthIdx === 0 ? selectedYear - 1 : selectedYear;
      return sameMonthYear(d, pm, py);
    });

    const avgDays = calcAvgDays(prevDone);

    const avgPeriodLabel = timeView === 'Año'
      ? `${selectedYear - 1}`
      : (() => {
        const pm = monthIdx === 0 ? 11 : monthIdx - 1;
        const py = monthIdx === 0 ? selectedYear - 1 : selectedYear;
        return `${MONTHS[pm]} ${py}`;
      })();

    // ── Retrasos: activas con actividad en el período ─────────────────────────
    const active = orders.filter(x =>
      x.estado && x.estado !== 'Anulada' && x.estado !== 'Enviado' && inPeriodActive(x)
    );
    let delayed = 0, onTrack = 0;
    active.forEach(x => {
      let isDelayed = false;
      const fe = x.deliveryDate || x.fecha_entrega;
      if (fe) { const ms = new Date(fe).getTime(); if (!isNaN(ms) && nowMs > ms) isDelayed = true; }
      if (!isDelayed && ESTADOS_EN_PRODUCCION.includes(x.estado) && (x.asignaciones || []).length > 0) {
        const entrada = (x.historial || []).find(h => ESTADOS_EN_PRODUCCION.includes(h.estado));
        const fechaEntrada = entrada?.fecha || x.updatedAt;
        if (fechaEntrada) {
          const dias = Math.round((nowMs - new Date(fechaEntrada).getTime()) / 86400000);
          if (dias > 17) isDelayed = true;
        }
      }
      isDelayed ? delayed++ : onTrack++;
    });

    return {
      stats: { current, completedThisMonth, pending, avgTime: avgDays !== null ? `${avgDays}d` : '—', periodLabel, avgPeriodLabel },
      generalStatus: { delayed, onTrack },
    };
  }, [orders, timeView, monthIdx, selectedYear, selectedMonth]);

  // ✅ Fix: las barras de "Estado general de producción" tenían alturas
  // fijas en el JSX (h-2 y h-30 — esta última ni siquiera es una clase
  // válida de Tailwind, el spacing scale salta de h-28 a h-32, así que
  // esa barra quedaba en 0px). Ninguna reflejaba generalStatus.delayed/
  // onTrack, por eso el gráfico nunca se movía. Ahora la altura se calcula
  // en px, proporcional al valor más alto entre ambas barras.
  const GENERAL_BAR_MAX_PX = 140;
  const generalMaxVal = Math.max(generalStatus.delayed, generalStatus.onTrack, 1);
  const delayedBarPx = generalStatus.delayed > 0
    ? Math.max(6, Math.round((generalStatus.delayed / generalMaxVal) * GENERAL_BAR_MAX_PX))
    : 4;
  const onTrackBarPx = generalStatus.onTrack > 0
    ? Math.max(6, Math.round((generalStatus.onTrack / generalMaxVal) * GENERAL_BAR_MAX_PX))
    : 4;

  const lineData = useMemo(() => {
    if (!orders.length) return [];

    const refDate = (o) => {
      const last = (o.historial || []).slice(-1)[0];
      const d = last?.fecha || o.updatedAt || o.createdAt;
      return d ? new Date(d) : null;
    };

    const matchPoint = (d, pointIndex) => {
      if (!d) return false;
      if (timeView === 'Año') return d.getMonth() === pointIndex && d.getFullYear() === selectedYear;
      if (timeView === 'Mes') return Math.ceil(d.getDate() / 7) === pointIndex + 1 && d.getMonth() === monthIdx && d.getFullYear() === new Date().getFullYear();
      if (timeView === 'Semana') {
        const dow = d.getDay() === 0 ? 6 : d.getDay() - 1;
        return dow === pointIndex && d.getMonth() === monthIdx && d.getFullYear() === selectedYear;
      }
      return false;
    };

    let points, labels;
    if (timeView === 'Año') {
      points = MONTHS.length; labels = MONTHS.map(m => m.slice(0, 3));
    } else if (timeView === 'Mes') {
      points = 4; labels = ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4'];
    } else {
      points = 7; labels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
    }

    return Array.from({ length: points }, (_, i) => {
      const point = { label: labels[i] };
      sedesNames.forEach(name => { point[name] = 0; });
      point.terceros = 0;

      orders.forEach(o => {
        const d = refDate(o);
        if (!matchPoint(d, i)) return;

        const qty = totalProductos(o);

        if ((o.asignaciones || []).length > 0) {
          point.terceros += qty || 1;
        }

        const ORDEN_TERMINADA = ['Empaque', 'Enviado'];
        const asigsSede = o.sedeAsignaciones || o.sede_asignaciones || [];
        if (ORDEN_TERMINADA.includes(o.estado) && asigsSede.length > 0) {
          asigsSede.forEach(a => {
            if (sedesNames.includes(a.option)) {
              point[a.option] = (point[a.option] || 0) + (Number(a.cantidad) || 0);
            }
          });
        } else if (ORDEN_TERMINADA.includes(o.estado) && sedesNames.length > 0) {
          const perSede = Math.round(qty / sedesNames.length) || 1;
          sedesNames.forEach(name => { point[name] = (point[name] || 0) + perSede; });
        }
      });

      return point;
    });
  }, [orders, sedesNames, timeView, selectedMonth, selectedYear, monthIdx]);

  // ── Barras: recalculadas al cambiar período de barras ─────────
  const barData = useMemo(() => {
    const counts = Object.fromEntries(BAR_PROCESSES.map(p => [p, 0]));
    orders.forEach(o => {
      if (!o.estado) return;
      const d = orderDate(o);
      if (!matchPeriod(d, barTimeView, monthIdx, selectedYear)) return;
      const proceso = ESTADO_TO_PROCESO[o.estado];
      if (proceso) counts[proceso]++;
    });
    return BAR_PROCESSES.map(name => ({ name, value: counts[name] }));
  }, [orders, barTimeView, monthIdx, selectedYear]);

  const showTerceros = viewMode === 'Todas' || viewMode === 'Terceros';

  // ── Órdenes que caen dentro del filtro activo de la página ──
  const filteredOrdersForExport = useMemo(() => {
    return orders.filter((o) => {
      if (matchPeriod(o.updatedAt, timeView, monthIdx, selectedYear)) return true;
      if (matchPeriod(o.createdAt, timeView, monthIdx, selectedYear)) return true;
      return (o.historial || []).some(h => matchPeriod(h.fecha, timeView, monthIdx, selectedYear));
    });
  }, [orders, timeView, monthIdx, selectedYear]);

  const [downloadingExcel, setDownloadingExcel] = useState(false);

  /* ══════════════════════════════════════════════════════════════════════
   * DESCARGA EXCEL — acepta un rango de fechas opcional del modal.
   * Si se proporcionan fechas, filtra las órdenes por ese rango; si no,
   * usa el período activo de la página (timeView).
   * ══════════════════════════════════════════════════════════════════════ */
  const handleDownloadExcel = async (dateFrom, dateTo) => {
    if (downloadingExcel) return;
    setDownloadingExcel(true);
    try {
      const ExcelJS = (await import('exceljs')).default;
      const wb = new ExcelJS.Workbook();
      wb.creator = 'UniStock';
      wb.created = new Date();

      const ARGB = (hex) => 'FF' + hex.replace('#', '').toUpperCase();
      const fillSolid = (hex) => ({ type: 'pattern', pattern: 'solid', fgColor: { argb: ARGB(hex) } });
      const thinBorder = (hex = '#FF4FD6') => {
        const c = { style: 'thin', color: { argb: ARGB(hex) } };
        return { top: c, bottom: c, left: c, right: c };
      };
      const now = new Date();
      const fechaGeneracion = now.toLocaleDateString('es-CO', { day: '2-digit', month: 'long', year: 'numeric' });

      // Determinar qué órdenes incluir según el rango del modal o el período de la página
      const hasRange = !!(dateFrom && dateTo);
      const ordersToExport = hasRange
        ? orders.filter((o) => {
            const from = new Date(`${dateFrom}T00:00:00`);
            const to = new Date(`${dateTo}T23:59:59.999`);
            const d = new Date(orderDate(o));
            return d >= from && d <= to;
          })
        : filteredOrdersForExport;

      const periodoTexto = hasRange
        ? `${new Date(`${dateFrom}T00:00:00`).toLocaleDateString('es-CO')} — ${new Date(`${dateTo}T00:00:00`).toLocaleDateString('es-CO')}`
        : (timeView === 'Semana' ? `${selectedMonth} ${selectedYear} (semana actual)`
          : timeView === 'Mes' ? `${selectedMonth} ${selectedYear}`
            : `Año ${selectedYear}`);

      let logoImageId = null;
      try {
        const logoRes = await fetch(putongasLogoUrl);
        const logoBlob = await logoRes.blob();
        const logoBase64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result.split(',')[1]);
          reader.onerror = reject;
          reader.readAsDataURL(logoBlob);
        });
        logoImageId = wb.addImage({ base64: logoBase64, extension: 'png' });
      } catch (e) {
        console.warn('[Dashboard] No se pudo cargar el logo para el Excel:', e);
      }

      // Colores de marca reutilizados en tablas y gráficos
      const PINK = '#FF4FD6';
      const bandFill = (i) => fillSolid(i % 2 === 0 ? '#FFFFFF' : '#FFF6FC');
      const sectionTitle = (ws, ref, text) => {
        ws.getCell(ref).value = text;
        ws.getCell(ref).font = { name: 'Arial', size: 12, bold: true, color: { argb: '000000' } };
        ws.getCell(ref).fill = fillSolid('#FFFFFF');
        ws.getCell(ref).alignment = { indent: 1 };
      };
      const tableHeader = (ws, row, cols, startCol = 2) => {
        row.height = 22;
        cols.forEach((h, i) => {
          const cell = row.getCell(i + startCol);
          cell.value = h;
          cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: ARGB(PINK) } };
          cell.fill = fillSolid('#FFFFFF');
          cell.alignment = { horizontal: i === 0 ? 'left' : 'right', vertical: 'middle', indent: i === 0 ? 1 : 0 };
          const pinkThin = { style: 'thin', color: { argb: ARGB(PINK) } };
          cell.border = { top: pinkThin, left: pinkThin, right: pinkThin, bottom: { style: 'medium', color: { argb: ARGB(PINK) } } };
        });
      };
      const footerNote = (ws, ref) => {
        ws.getCell(ref).value = `Generado automáticamente por UniStock el ${fechaGeneracion}. Las cifras reflejan el estado del sistema al momento de la descarga.`;
        ws.getCell(ref).font = { name: 'Arial', size: 8, italic: true, color: { argb: 'FF9CA3AF' } };
        ws.getCell(ref).alignment = { indent: 1 };
      };
      // Convierte una altura de imagen en píxeles a una cantidad aproximada
      // de filas de hoja (para reservar espacio y que nada se solape).
      const ROW_PX = 19;
      const rowsForPx = (px) => Math.ceil(px / ROW_PX) + 1;

      const PAGE_SETUP = { orientation: 'landscape', fitToPage: true, margins: { top: 0.5, bottom: 0.5, left: 0.4, right: 0.4 } };
      const setPrintFooter = (ws, sheetLabel) => {
        ws.headerFooter = {
          oddFooter: `&L&8UniStock — ${sheetLabel}&C&8Página &P de &N&R&8Generado el ${fechaGeneracion}`,
        };
      };

      // Umbral de "alerta de capacidad" — igual que en el panel del dashboard
      const barLimit = barTimeView === 'Día' ? 10 : barTimeView === 'Mes' ? 24 : 38;
      const totalActivasRetraso = generalStatus.delayed + generalStatus.onTrack;
      const cumplimientoPct = totalActivasRetraso > 0 ? Math.round((generalStatus.onTrack / totalActivasRetraso) * 100) : null;

      /* ══════════════════════════ Hoja 0: Portada ══════════════════════════ */
      const wsPortada = wb.addWorksheet('Portada', { pageSetup: PAGE_SETUP, properties: { tabColor: { argb: ARGB(PINK) } } });
      wsPortada.columns = [{ width: 4 }, { width: 30 }, { width: 22 }, { width: 22 }, { width: 22 }, { width: 22 }];
      setPrintFooter(wsPortada, 'Portada');

      wsPortada.getRow(1).height = 8;
      if (logoImageId) wsPortada.addImage(logoImageId, { tl: { col: 1.3, row: 1.4 }, ext: { width: 92, height: 120 } });

      wsPortada.mergeCells('C3:F5');
      wsPortada.getCell('C3').value = 'Dashboard de Producción';
      wsPortada.getCell('C3').font = { name: 'Arial', size: 26, bold: true, color: { argb: '1A1A2E' } };
      wsPortada.getCell('C3').alignment = { horizontal: 'left', vertical: 'bottom' };

      wsPortada.mergeCells('C6:F6');
      wsPortada.getCell('C6').value = 'Sistema de Gestión UniStock';
      wsPortada.getCell('C6').font = { name: 'Arial', size: 13, color: { argb: ARGB(PINK) }, bold: true };

      wsPortada.mergeCells('C7:F7');
      wsPortada.getCell('C7').value = `Generado el ${fechaGeneracion}  ·  Período: ${periodoTexto}`;
      wsPortada.getCell('C7').font = { name: 'Arial', size: 10, color: { argb: 'FF6B7280' } };

      [1, 2, 3, 4, 5, 6, 7, 8].forEach(r => { wsPortada.getRow(r).height = r === 3 ? 24 : wsPortada.getRow(r).height; });

      // Franja de color de marca bajo el encabezado
      wsPortada.mergeCells('B9:F9');
      wsPortada.getRow(9).height = 6;
      wsPortada.getCell('B9').fill = fillSolid(PINK);

      // Índice de contenidos con hipervínculos internos
      wsPortada.mergeCells('B11:F11');
      sectionTitle(wsPortada, 'B11', 'Contenido de este reporte');

      const tocRows = [
        { sheet: 'Resumen', desc: 'Indicadores clave, comparativa de retrasos y órdenes por proceso.' },
        { sheet: 'Productos por Sede', desc: 'Unidades asignadas a cada sede y a terceros en el tiempo.' },
      ];
      tocRows.forEach((t, i) => {
        const row = wsPortada.getRow(12 + i);
        row.height = 22;
        const linkCell = row.getCell(2);
        linkCell.value = { text: `→ ${t.sheet}`, hyperlink: `#'${t.sheet}'!A1` };
        linkCell.font = { name: 'Arial', size: 11, bold: true, color: { argb: ARGB(PINK) }, underline: true };
        row.getCell(3).value = t.desc;
        row.getCell(3).font = { name: 'Arial', size: 10, color: { argb: 'FF374151' } };
      });

      // Indicadores destacados en portada (misma cifra que en Resumen, para
      // que la portada sirva como "vista de una sola página").
      const portadaKpiRowIdx = 12 + tocRows.length + 2;
      const portadaKpis = [
        { label: 'Producciones actuales', value: stats.current || 0 },
        { label: stats.periodLabel ? `Completadas ${stats.periodLabel}` : 'Completadas', value: stats.completedThisMonth || 0 },
        { label: 'Tasa de cumplimiento', value: cumplimientoPct !== null ? `${cumplimientoPct}%` : '—' },
        { label: 'Con retraso', value: generalStatus.delayed || 0 },
      ];
      portadaKpis.forEach((k, i) => {
        const col = 2 + i; // B,C,D,E
        const letter = wsPortada.getColumn(col).letter;
        wsPortada.getCell(`${letter}${portadaKpiRowIdx}`).value = k.value;
        wsPortada.getCell(`${letter}${portadaKpiRowIdx}`).font = { name: 'Arial', size: 18, bold: true, color: { argb: ARGB(PINK) } };
        wsPortada.getCell(`${letter}${portadaKpiRowIdx + 1}`).value = k.label;
        wsPortada.getCell(`${letter}${portadaKpiRowIdx + 1}`).font = { name: 'Arial', size: 9, color: { argb: 'FF6B7280' } };
        wsPortada.getCell(`${letter}${portadaKpiRowIdx + 1}`).alignment = { wrapText: true };
      });
      wsPortada.getRow(portadaKpiRowIdx).height = 26;

      footerNote(wsPortada, `B${portadaKpiRowIdx + 3}`);
      wsPortada.mergeCells(`B${portadaKpiRowIdx + 3}:F${portadaKpiRowIdx + 3}`);

      /* ══════════════════════════ Hoja 1: Resumen ══════════════════════════ */
      const wsResumen = wb.addWorksheet('Resumen', { pageSetup: PAGE_SETUP, properties: { tabColor: { argb: ARGB('#a855f7') } } });
      setPrintFooter(wsResumen, 'Resumen');
      wsResumen.columns = [
        { key: 'a', width: 3 }, { key: 'b', width: 24 }, { key: 'c', width: 15 }, { key: 'd', width: 15 },
        { key: 'e', width: 15 }, { key: 'f', width: 15 }, { key: 'g', width: 15 }, { key: 'h', width: 15 },
      ];

      if (logoImageId) wsResumen.addImage(logoImageId, { tl: { col: 0.15, row: 0.15 }, ext: { width: 46, height: 60 } });

      wsResumen.mergeCells('B1:H1');
      wsResumen.getRow(1).height = 30;
      wsResumen.getCell('B1').value = 'Dashboard de Producción — Sistema de Gestión UniStock';
      wsResumen.getCell('B1').font = { name: 'Arial', size: 15, bold: true, color: { argb: '000000' } };
      wsResumen.getCell('B1').alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
      ['A1', 'B1'].forEach(ref => { wsResumen.getCell(ref).fill = fillSolid('#FFFFFF'); });

      wsResumen.mergeCells('B2:E2');
      wsResumen.getRow(2).height = 18;
      wsResumen.getCell('B2').value = `Generado el ${fechaGeneracion}  ·  Período: ${periodoTexto}`;
      wsResumen.getCell('B2').font = { name: 'Arial', size: 10, color: { argb: '#000000' } };
      wsResumen.getCell('B2').alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
      ['A2', 'B2'].forEach(ref => { wsResumen.getCell(ref).fill = fillSolid('#FFFFFF'); });
      wsResumen.getCell('B2').border = { bottom: { style: 'thin', color: { argb: ARGB(PINK) } } };

      wsResumen.getRow(3).height = 6;

      // ── Tira de indicadores ejecutivos (lectura de un vistazo) ──────────
      const cardPairs = [['B', 'C'], ['D', 'E'], ['F', 'G']];
      const cards = [
        { label: 'Producciones actuales', value: stats.current || 0, color: '#a855f7', bg: '#F5F0FF' },
        { label: stats.periodLabel ? `Completadas ${stats.periodLabel}` : 'Completadas', value: stats.completedThisMonth || 0, color: '#22c55e', bg: '#EEFCF3' },
        {
          label: 'Tasa de cumplimiento', value: cumplimientoPct !== null ? `${cumplimientoPct}%` : '—',
          color: cumplimientoPct === null ? '#9ca3af' : cumplimientoPct >= 80 ? '#22c55e' : cumplimientoPct >= 50 ? '#f59e0b' : '#ef4444',
          bg: cumplimientoPct === null ? '#F5F5F5' : cumplimientoPct >= 80 ? '#EEFCF3' : cumplimientoPct >= 50 ? '#FFF7E6' : '#FEF1F2',
        },
      ];
      cards.forEach(({ label, value, color, bg }, i) => {
        const [c1, c2] = cardPairs[i];
        wsResumen.mergeCells(`${c1}4:${c2}5`);
        wsResumen.mergeCells(`${c1}6:${c2}6`);
        const numCell = wsResumen.getCell(`${c1}4`);
        numCell.value = value;
        numCell.font = { name: 'Arial', size: 22, bold: true, color: { argb: ARGB(color) } };
        numCell.alignment = { horizontal: 'center', vertical: 'middle' };
        const labelCell = wsResumen.getCell(`${c1}6`);
        labelCell.value = label;
        labelCell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FF374151' } };
        labelCell.alignment = { horizontal: 'center', vertical: 'middle' };
        [`${c1}4`, `${c2}4`, `${c1}5`, `${c2}5`, `${c1}6`, `${c2}6`].forEach(ref => {
          wsResumen.getCell(ref).fill = fillSolid(bg);
        });
        wsResumen.getCell(`${c1}4`).border = { top: { style: 'thin', color: { argb: ARGB(color) } }, left: { style: 'thin', color: { argb: ARGB(color) } } };
        wsResumen.getCell(`${c2}4`).border = { top: { style: 'thin', color: { argb: ARGB(color) } }, right: { style: 'thin', color: { argb: ARGB(color) } } };
        wsResumen.getCell(`${c1}6`).border = { bottom: { style: 'thin', color: { argb: ARGB(color) } }, left: { style: 'thin', color: { argb: ARGB(color) } } };
        wsResumen.getCell(`${c2}6`).border = { bottom: { style: 'thin', color: { argb: ARGB(color) } }, right: { style: 'thin', color: { argb: ARGB(color) } } };
      });
      [4, 5, 6].forEach(r => { wsResumen.getRow(r).height = r === 6 ? 20 : 26; });

      wsResumen.getRow(7).height = 10;

      // ── Tabla de KPIs + gráfico de retrasos vs en orden, lado a lado ────
      const kpiHeaderRowIdx = 8;
      tableHeader(wsResumen, wsResumen.getRow(kpiHeaderRowIdx), ['Indicador', 'Valor']);
      const kpiRows = [
        ['Producciones actuales', stats.current || 0],
        [stats.periodLabel ? `Completadas ${stats.periodLabel}` : 'Completadas', stats.completedThisMonth || 0],
        ['Por iniciar', stats.pending || 0],
        [stats.avgPeriodLabel ? `Tiempo promedio (${stats.avgPeriodLabel})` : 'Tiempo promedio', stats.avgTime || '—'],
        ['Producciones con retraso', generalStatus.delayed || 0],
        ['Producciones en orden', generalStatus.onTrack || 0],
        ['Total de órdenes en el período', ordersToExport.length],
      ];
      kpiRows.forEach((vals, i) => {
        const row = wsResumen.getRow(kpiHeaderRowIdx + 1 + i);
        row.height = 19;
        vals.forEach((v, ci) => {
          const cell = row.getCell(ci + 2);
          cell.value = v;
          cell.fill = bandFill(i);
          cell.border = thinBorder();
          cell.alignment = { horizontal: ci === 1 ? 'right' : 'left', vertical: 'middle', indent: ci === 1 ? 0 : 1 };
          cell.font = ci === 1
            ? { name: 'Arial', size: 10, bold: true, color: { argb: ARGB('#a858d6') } }
            : { name: 'Arial', size: 10, color: { argb: 'FF374151' } };
          if (ci === 1 && typeof v === 'number') cell.numFmt = '#,##0';
        });
      });

      // Gráfico "Con retraso / En orden" — junto a la tabla de KPIs
      const delayChartB64 = drawBarChartPng({
        width: 300, height: 230,
        categories: ['Con retraso', 'En orden'],
        values: [generalStatus.delayed, generalStatus.onTrack],
        colorFor: (v, i) => (i === 0 ? '#f472b6' : '#4ade80'),
        title: 'Producciones: retraso vs. en orden',
        yLabel: 'Órdenes',
      });
      const delayChartImgId = wb.addImage({ base64: delayChartB64, extension: 'png' });
      wsResumen.addImage(delayChartImgId, { tl: { col: 4.1, row: kpiHeaderRowIdx - 1 }, ext: { width: 300, height: 230 } });

      const kpiTableBottomRow = kpiHeaderRowIdx + kpiRows.length; // última fila con datos
      const afterKpiRow = Math.max(kpiTableBottomRow, kpiHeaderRowIdx - 1 + rowsForPx(230)) + 2; // deja espacio para el gráfico

      // ── Tabla de procesos (barData) + gráfico de barras ──────────────────
      const procTitleRowIdx = afterKpiRow;
      wsResumen.mergeCells(`B${procTitleRowIdx}:H${procTitleRowIdx}`);
      sectionTitle(wsResumen, `B${procTitleRowIdx}`, 'Órdenes por proceso');

      const procHeaderRowIdx = procTitleRowIdx + 1;
      tableHeader(wsResumen, wsResumen.getRow(procHeaderRowIdx), ['Proceso', 'Cantidad']);
      wsResumen.getCell(`B${procHeaderRowIdx}`).alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
      barData.forEach((p, i) => {
        const row = wsResumen.getRow(procHeaderRowIdx + 1 + i);
        row.height = 18;
        [p.name, p.value].forEach((v, ci) => {
          const cell = row.getCell(ci + 2);
          cell.value = v;
          cell.fill = bandFill(i);
          cell.border = thinBorder();
          cell.alignment = { horizontal: ci === 1 ? 'right' : 'left', vertical: 'middle', indent: ci === 1 ? 0 : 1 };
          cell.font = { name: 'Arial', size: 10, color: { argb: ci === 1 && p.value >= barLimit ? 'FFDB2777' : 'FF374151' }, bold: ci === 1 && p.value >= barLimit };
          if (ci === 1) cell.numFmt = '#,##0';
        });
      });
      wsResumen.autoFilter = { from: { row: procHeaderRowIdx, column: 2 }, to: { row: procHeaderRowIdx + barData.length, column: 3 } };

      const procChartB64 = drawBarChartPng({
        width: 460, height: 260,
        categories: BAR_PROCESSES,
        values: barData.map(p => p.value),
        colorFor: (v) => (v >= barLimit ? '#E8B4E8' : '#7BE87B'),
        title: 'Estado general de los procesos de producción',
        yLabel: 'Cantidad',
      });
      const procChartImgId = wb.addImage({ base64: procChartB64, extension: 'png' });
      wsResumen.addImage(procChartImgId, { tl: { col: 4.1, row: procHeaderRowIdx - 1 }, ext: { width: 460, height: 260 } });

      const procTableBottomRow = procHeaderRowIdx + barData.length;
      const afterProcRow = Math.max(procTableBottomRow, procHeaderRowIdx - 1 + rowsForPx(260)) + 2;

      wsResumen.getCell(`B${afterProcRow}`).value =
        `Los procesos resaltados superan el límite de capacidad del período (día ≥ 10 · mes ≥ 24 · año ≥ 38) y pueden requerir atención.`;
      wsResumen.getCell(`B${afterProcRow}`).font = { name: 'Arial', size: 9, italic: true, color: { argb: 'FFDB2777' } };
      wsResumen.getCell(`B${afterProcRow}`).alignment = { indent: 1, wrapText: true };
      wsResumen.mergeCells(`B${afterProcRow}:H${afterProcRow}`);

      footerNote(wsResumen, `B${afterProcRow + 2}`);
      wsResumen.mergeCells(`B${afterProcRow + 2}:H${afterProcRow + 2}`);
      wsResumen.views = [{ state: 'frozen', ySplit: 3 }];

      /* ═══════════════════ Hoja 2: Productos por Sede ═══════════════════ */
      const wsSedes = wb.addWorksheet('Productos por Sede', { pageSetup: PAGE_SETUP, properties: { tabColor: { argb: ARGB('#22c55e') } } });
      setPrintFooter(wsSedes, 'Productos por Sede');
      const sedeCols = [
        { key: 'a', width: 3 }, { key: 'b', width: 18 },
        ...sedesNames.map(() => ({ width: 14 })),
        { width: 14 }, { width: 14 },
      ];
      wsSedes.columns = sedeCols;

      const lastColIdx = 2 + sedesNames.length + 2; // A=1..B=2, sedes..., Terceros, Total
      const lastColLetter = wsSedes.getColumn(lastColIdx).letter;

      if (logoImageId) wsSedes.addImage(logoImageId, { tl: { col: 0.15, row: 0.15 }, ext: { width: 46, height: 60 } });

      wsSedes.mergeCells(`B1:${lastColLetter}1`);
      wsSedes.getRow(1).height = 30;
      wsSedes.getCell('B1').value = 'Productos asignados a las sedes — Sistema de Gestión UniStock';
      wsSedes.getCell('B1').font = { name: 'Arial', size: 15, bold: true, color: { argb: '000000' } };
      wsSedes.getCell('B1').alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };

      wsSedes.mergeCells(`B2:${lastColLetter}2`);
      wsSedes.getRow(2).height = 18;
      const vistaTexto = timeView === 'Semana' ? `${selectedMonth} ${selectedYear} — por semana`
        : timeView === 'Mes' ? `${selectedMonth} ${selectedYear} — por semana del mes`
          : `Año ${selectedYear} — por mes`;
      wsSedes.getCell('B2').value = `Generado el ${fechaGeneracion}  ·  Vista: ${vistaTexto}`;
      wsSedes.getCell('B2').font = { name: 'Arial', size: 10, color: { argb: '#000000' } };
      wsSedes.getCell('B2').alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
      wsSedes.getCell('B2').border = { bottom: { style: 'thin', color: { argb: ARGB(PINK) } } };

      wsSedes.getRow(3).height = 6;

      const sedeHeaderRowIdx = 4;
      const sedeHeaders = ['Período', ...sedesNames, 'Terceros', 'Total'];
      tableHeader(wsSedes, wsSedes.getRow(sedeHeaderRowIdx), sedeHeaders);
      wsSedes.getCell(`B${sedeHeaderRowIdx}`).alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };

      const totals = new Array(sedesNames.length + 1).fill(0); // sedes..., terceros
      lineData.forEach((point, i) => {
        const row = wsSedes.getRow(sedeHeaderRowIdx + 1 + i);
        row.height = 18;
        const sedeValues = sedesNames.map(name => Number(point[name]) || 0);
        const tercerosVal = Number(point.terceros) || 0;
        sedeValues.forEach((v, si) => { totals[si] += v; });
        totals[sedesNames.length] += tercerosVal;
        const rowTotal = sedeValues.reduce((s, v) => s + v, 0) + tercerosVal;
        const rowVals = [point.label, ...sedeValues, tercerosVal, rowTotal];
        rowVals.forEach((v, ci) => {
          const cell = row.getCell(ci + 2);
          cell.value = v;
          cell.fill = bandFill(i);
          cell.border = thinBorder();
          cell.alignment = { horizontal: ci === 0 ? 'left' : 'right', vertical: 'middle', indent: ci === 0 ? 1 : 0 };
          cell.font = ci === rowVals.length - 1
            ? { name: 'Arial', size: 10, bold: true, color: { argb: ARGB('#a858d6') } }
            : { name: 'Arial', size: 10, color: { argb: 'FF374151' } };
          if (ci > 0) cell.numFmt = '#,##0';
        });
      });
      if (lineData.length > 0) {
        wsSedes.autoFilter = { from: { row: sedeHeaderRowIdx, column: 2 }, to: { row: sedeHeaderRowIdx + lineData.length, column: 1 + sedeHeaders.length } };
      }

      const totalsRowIdx = sedeHeaderRowIdx + 1 + lineData.length;
      const totalsRow = wsSedes.getRow(totalsRowIdx);
      totalsRow.height = 20;
      const grandTotal = totals.reduce((s, v) => s + v, 0);
      const totalsVals = ['Total período', ...totals, grandTotal];
      totalsVals.forEach((v, ci) => {
        const cell = totalsRow.getCell(ci + 2);
        cell.value = v;
        cell.fill = fillSolid('#FFF0FA');
        cell.border = { top: { style: 'medium', color: { argb: ARGB(PINK) } }, bottom: { style: 'medium', color: { argb: ARGB(PINK) } }, left: thinBorder().left, right: thinBorder().right };
        cell.alignment = { horizontal: ci === 0 ? 'left' : 'right', vertical: 'middle', indent: ci === 0 ? 1 : 0 };
        cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: ARGB(PINK) } };
        if (ci > 0) cell.numFmt = '#,##0';
      });

      // ── Gráfico de líneas: productos asignados en el tiempo ──────────────
      const sedeSeries = sedesNames.map((name, i) => ({
        name, color: SEDE_COLORS[i % SEDE_COLORS.length],
        values: lineData.map(p => Number(p[name]) || 0),
      }));
      sedeSeries.push({ name: 'Terceros', color: '#22c55e', values: lineData.map(p => Number(p.terceros) || 0) });

      const sedesChartRowIdx = totalsRowIdx + 2;
      if (lineData.length > 0) {
        const sedesChartB64 = drawLineChartPng({
          width: 720, height: 300,
          labels: lineData.map(p => p.label),
          series: sedeSeries,
          title: 'Productos asignados a las sedes en el tiempo',
          yLabel: 'Unidades',
        });
        const sedesChartImgId = wb.addImage({ base64: sedesChartB64, extension: 'png' });
        wsSedes.addImage(sedesChartImgId, { tl: { col: 1.1, row: sedesChartRowIdx - 1 }, ext: { width: 720, height: 300 } });
      } else {
        wsSedes.getCell(`B${sedesChartRowIdx}`).value = 'No hay datos suficientes para graficar en el período seleccionado.';
        wsSedes.getCell(`B${sedesChartRowIdx}`).font = { name: 'Arial', size: 10, italic: true, color: { argb: 'FF9CA3AF' } };
      }

      const sedesChartRowsTall = lineData.length > 0 ? rowsForPx(300) : 1;
      footerNote(wsSedes, `B${sedesChartRowIdx + sedesChartRowsTall + 1}`);
      wsSedes.mergeCells(`B${sedesChartRowIdx + sedesChartRowsTall + 1}:${lastColLetter}${sedesChartRowIdx + sedesChartRowsTall + 1}`);
      wsSedes.views = [{ state: 'frozen', ySplit: 3 }];

      wb.views = [{ activeTab: 0, firstSheet: 0 }];

      const buffer = await wb.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const suffix = hasRange ? `${dateFrom}_a_${dateTo}` : `${(timeView || '').toLowerCase()}`;
      link.download = `dashboard-produccion-${suffix}.xlsx`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('[Dashboard] Error generando el Excel:', e);
    } finally {
      setDownloadingExcel(false);
    }
  };

  const GlobalTimeFilter = () => (
    <div className="flex items-center gap-2">
      {timeView === 'Semana' && <>
        <Dropdown value={selectedMonth} options={MONTHS} onChange={setSelectedMonth} />
        <Dropdown value={selectedYear} options={YEARS} onChange={setSelectedYear} />
      </>}
      {timeView === 'Mes' && <Dropdown value={selectedMonth} options={MONTHS} onChange={setSelectedMonth} />}
      {timeView === 'Año' && <Dropdown value={selectedYear} options={YEARS} onChange={setSelectedYear} />}
      <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-xl p-0.5">
        {['Semana', 'Mes', 'Año'].map(p => (
          <button key={p} onClick={() => setTimeView(p)}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${timeView === p ? 'bg-fuchsia-500 text-white' : 'text-gray-500 hover:text-gray-800'}`}>
            {p}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen p-5" >
      {/* Encabezado */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h1 className="text-xl font-bold text-gray-900" style={{ fontSize: '26px', fontWeight: '700', color: '#1a1a1a', margin: '0' }}>Dashboard</h1>
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-sm text-gray-500 font-medium">Período:</span>
          <GlobalTimeFilter />

          {/* ── Botón de descarga de reporte Excel ── */}
          <button
            onClick={() => { setModalDateFrom(''); setModalDateTo(''); setShowDownloadModal(true); }}
            disabled={downloadingExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-semibold text-white transition-opacity"
            style={{ background: '#FF4FD6', opacity: downloadingExcel ? 0.6 : 1, cursor: downloadingExcel ? 'not-allowed' : 'pointer' }}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            {downloadingExcel ? 'Generando...' : 'Descargar reporte'}
          </button>
        </div>
      </div>

      {/* ── Modal de descarga con filtro de fechas ── */}
      {showDownloadModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1200, padding: '0 16px' }}>
          <div style={{ borderRadius: 16, padding: 24, background: '#fff', boxShadow: '0 12px 40px rgba(0,0,0,0.18)', width: 'calc(100vw - 32px)', maxWidth: 400, animation: 'fadeIn 0.18s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <div>
                <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#FF4FD6' }}>Descargar reporte</h3>
                <p style={{ margin: '3px 0 0', fontSize: 12, color: '#888' }}>Selecciona un rango de fechas para el reporte</p>
              </div>
              <button onClick={() => setShowDownloadModal(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 20, lineHeight: 1, padding: 4 }}>×</button>
            </div>

            <div style={{ marginBottom: 16 }}>
              <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-xl px-3 py-2">
                <span className="text-xs text-gray-500 font-medium pl-1">Del</span>
                <input
                  type="date"
                  value={modalDateFrom}
                  max={modalDateTo || undefined}
                  onChange={(e) => setModalDateFrom(e.target.value)}
                  className="text-xs text-gray-800 border-none outline-none bg-transparent flex-1"
                  style={{ colorScheme: 'light' }}
                />
                <span className="text-xs text-gray-500 font-medium">al</span>
                <input
                  type="date"
                  value={modalDateTo}
                  min={modalDateFrom || undefined}
                  onChange={(e) => setModalDateTo(e.target.value)}
                  className="text-xs text-gray-800 border-none outline-none bg-transparent flex-1"
                  style={{ colorScheme: 'light' }}
                />
              </div>
              {modalRangeError && (
                <p style={{ margin: '6px 0 0', fontSize: 11, color: '#dc2626', fontWeight: 500 }}>
                  La fecha "Del" no puede ser posterior a la fecha "al".
                </p>
              )}
              <p style={{ margin: '8px 0 0', fontSize: 11, color: '#9ca3af', textAlign: 'center' }}>
                Si no seleccionas fechas, se usará el período activo del dashboard.
              </p>
            </div>

            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button
                onClick={() => setShowDownloadModal(false)}
                style={{ padding: '8px 16px', borderRadius: 8, border: '1.5px solid #e5e7eb', background: '#fff', color: '#374151', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  const hasBothDates = modalDateFrom && modalDateTo;
                  if (hasBothDates && modalRangeError) return;
                  const isRange = !!(modalDateFrom && modalDateTo);
                  setShowDownloadModal(false);
                  handleDownloadExcel(isRange ? modalDateFrom : null, isRange ? modalDateTo : null);
                }}
                disabled={downloadingExcel || (modalDateFrom && modalDateTo && modalRangeError)}
                style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: '#FF4FD6', color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer', opacity: (downloadingExcel || (modalDateFrom && modalDateTo && modalRangeError)) ? 0.6 : 1 }}
              >
                {downloadingExcel ? 'Generando...' : 'Descargar'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fila 1: Stats */}
      <Card className="mb-4">
        <h3 className="text-base font-bold text-gray-900 mb-4">Estado general de producción</h3>
        <div className="grid grid-cols-4 gap-3">
          {[
            {
              label: 'Producciones actuales', value: stats.current || '—',
              icon: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /></svg>,
              color: 'text-fuchsia-600 bg-fuchsia-50 border-fuchsia-200'
            },
            {
              label: stats.periodLabel ? `Completadas ${stats.periodLabel}` : 'Completadas', value: stats.completedThisMonth || '—',
              icon: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><polyline points="20 6 9 17 4 12" /></svg>,
              color: 'text-fuchsia-600 bg-fuchsia-50 border-fuchsia-200'
            },
            {
              label: 'Por iniciar', value: stats.pending || '—',
              icon: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>,
              color: 'text-pink-600 bg-pink-50 border-pink-200'
            },
            {
              label: stats.avgPeriodLabel ? `Tiempo promedio (${stats.avgPeriodLabel})` : 'Tiempo promedio', value: stats.avgTime || '—',
              icon: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg>,
              color: 'text-pink-500 bg-pink-50 border-pink-200'
            },
          ].map(({ label, value, icon, color }) => (
            <div key={label} className="rounded-xl px-4 py-3 bg-white" style={{ border: '1.5px solid #e5e7eb' }}>
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-6 h-6 rounded-md border flex items-center justify-center ${color}`}>{icon}</div>
                <p className="text-xs font-medium text-gray-700">{label}</p>
              </div>
              <p className="text-3xl font-bold text-gray-900">{value}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Fila 2: gráfica + panel */}
      <div className="flex gap-4 mb-4">
        <Card className="flex-1">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Productos asignados a las sedes</h2>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm text-gray-600">Último mes</span>
              <button onClick={() => setViewMode('Todas')}
                className={`px-3 py-0.5 rounded-full text-sm font-medium border transition-colors ${viewMode === 'Todas' ? 'bg-fuchsia-500 text-white border-fuchsia-500' : 'bg-white text-gray-600 border-gray-200'}`}>
                Todas
              </button>
              <button onClick={() => setViewMode('Terceros')}
                className={`flex items-center gap-1.5 px-3 py-0.5 rounded-full text-sm font-medium bg-white border transition-colors ${viewMode === 'Terceros' ? 'border-green-400 text-gray-800' : 'border-gray-200 text-gray-600'}`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="8" height="8" viewBox="0 0 10 10"><polygon points="5,0 10,10 0,10" fill="#22c55e" /></svg>
                Terceros
              </button>
              {sedesNames.map((name, i) => (
                <button key={name} onClick={() => setViewMode(name)}
                  className={`flex items-center gap-1.5 px-3 py-0.5 rounded-full text-sm font-medium bg-white border transition-colors ${viewMode === name ? 'border-gray-400 text-gray-800' : 'border-gray-200 text-gray-600'}`}>
                  <span className="w-3 h-3 inline-block rounded-sm" style={{ background: SEDE_COLORS[i % SEDE_COLORS.length] }} />
                  {name}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d946ef" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <span>Período: <span className="font-semibold text-fuchsia-600">
                {timeView === 'Semana' ? `${selectedMonth} ${selectedYear} — por semana` :
                  timeView === 'Mes' ? `${selectedMonth} ${selectedYear}` : `Año ${selectedYear}`}
              </span></span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={lineData} margin={{ top: 5, right: 10, left: -5, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#F5D8F5" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#4b5563' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#4b5563' }} axisLine={false} tickLine={false}
                label={{ value: 'Órdenes de producción', angle: -90, position: 'insideLeft', dx: 10, style: { fontSize: 10, fill: '#d946ef', textAnchor: 'middle' } }} />
              <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #fce7f3', fontSize: 12, color: '#111827' }} />
              {showTerceros && <Line type="monotone" dataKey="terceros" stroke="#22c55e" strokeWidth={2} dot={false} name="Terceros" />}
              {sedesNames.map((name, i) =>
                (viewMode === 'Todas' || viewMode === name)
                  ? <Line key={name} type="monotone" dataKey={name} stroke={SEDE_COLORS[i % SEDE_COLORS.length]} strokeWidth={i === 0 ? 2 : 1.5} dot={false} name={name} />
                  : null
              )}
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <div className="w-72 flex flex-col gap-4">
          <Card className="flex-1">
            <h3 className="text-sm font-bold text-gray-900 mb-3">Estado general de producción</h3>
            <div className="flex items-end justify-around h-48">
              <div className="flex flex-col items-center gap-1">
                <span className="text-xl font-bold">{generalStatus.delayed}</span>
                <div className="w-10 rounded-lg bg-pink-300" style={{ height: delayedBarPx, transition: 'height 0.3s ease' }} />
                <p className="text-xs text-center text-gray-700 font-medium mt-1">Producciones<br />con retraso</p>
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="text-xl font-bold">{generalStatus.onTrack}</span>
                <div className="w-10 rounded-lg bg-green-400" style={{ height: onTrackBarPx, transition: 'height 0.3s ease' }} />
                <p className="text-xs text-center text-gray-700 font-medium mt-1">Todo en<br />orden</p>
              </div>
            </div>
          </Card>

          <Card>
            <h3 className="text-sm font-bold text-gray-900 mb-4 text-center">Insumos</h3>
<div className="space-y-3">
              {/* Almacenamiento */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-fuchsia-50 border border-fuchsia-200 flex items-center justify-center shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="15" viewBox="0 0 44 27" fill="none">
                      <path d="M39.6436 0.607422H3.86044C2.06385 0.607422 0.607422 1.47356 0.607422 2.542V23.8224C0.607422 24.8908 2.06385 25.757 3.86044 25.757H39.6436C41.4402 25.757 42.8966 24.8908 42.8966 23.8224V2.542C42.8966 1.47356 41.4402 0.607422 39.6436 0.607422Z" stroke="#e040b8" strokeWidth="1.21519" strokeLinecap="round" strokeLinejoin="round" />
                      <path d="M28.2572 0.607422V10.2803C28.2572 10.5369 28.0858 10.7829 27.7808 10.9643C27.4757 11.1457 27.062 11.2476 26.6307 11.2476H16.8716C16.4402 11.2476 16.0265 11.1457 15.7215 10.9643C15.4165 10.7829 15.2451 10.5369 15.2451 10.2803V0.607422" stroke="#e040b8" strokeWidth="1.21519" strokeLinecap="round" strokeLinejoin="round" />
                      <path d="M26.6318 20.9194H34.7644" stroke="#e040b8" strokeWidth="1.21519" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-800 block">Almacenamiento</span>
                    <span className="text-xs text-gray-400">Total de insumos</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-12 h-px bg-pink-200 inline-block" />
                  <span className="text-sm font-bold text-gray-900">{supplies.almacenamiento}</span>
                </div>
              </div>

              {/* Stock */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-fuchsia-500 flex items-center justify-center shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="17" viewBox="0 0 48 31" fill="none">
                      <path d="M43.0099 7.76605H33.2673V6.61077C33.2673 2.95238 29.6238 0 25.1089 0H22.8119C18.297 0 14.6535 2.95238 14.6535 6.61077V7.76605H4.9901C2.29703 7.76605 0 9.56315 0 11.8095V26.9565C0 29.1387 2.21782 31 4.9901 31H43.0099C45.703 31 48 29.2029 48 26.9565V11.7453C48 9.56315 45.703 7.76605 43.0099 7.76605ZM18.297 6.61077C18.297 4.55694 20.3564 2.8882 22.8911 2.8882H25.1881C27.7228 2.8882 29.7822 4.55694 29.7822 6.61077V7.76605H18.297V6.61077ZM4.9901 10.6542H43.0099C43.802 10.6542 44.4356 11.1677 44.4356 11.8095V15.4037H39.7624V14.1843C39.7624 13.4141 38.9703 12.7081 37.9406 12.7081C36.9109 12.7081 36.1188 13.3499 36.1188 14.1843V15.4037H11.8812V14.1843C11.8812 13.4141 11.0891 12.7081 10.0594 12.7081C9.0297 12.7081 8.23762 13.3499 8.23762 14.1843V15.4037H3.64356V11.8095C3.64356 11.1677 4.19802 10.6542 4.9901 10.6542ZM43.0099 28.0476H4.9901C4.19802 28.0476 3.56436 27.5342 3.56436 26.8923V18.2277H8.23762V19.4472C8.23762 20.2174 9.0297 20.9234 10.0594 20.9234C11.0891 20.9234 11.8812 20.2816 11.8812 19.4472V18.2277H36.1188V19.4472C36.1188 20.2174 36.9109 20.9234 37.9406 20.9234C38.9703 20.9234 39.7624 20.2816 39.7624 19.4472V18.2277H44.4356V26.8923C44.4356 27.5342 43.802 28.0476 43.0099 28.0476Z" fill="white" />
                    </svg>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-blanck block">Stock</span>
                    <span className="text-xs" style={{ color: '#f5d0fe' }}>Unidades totales</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-12 h-px bg-pink-200 inline-block" />
                  <span className="text-sm font-bold text-gray-900">
                    {supplies.stock.toLocaleString('es-CO')}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Fila 3: barras */}
      <Card>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-gray-900">Estado general de los procesos de producción</h3>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d946ef" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <span>Período: <span className="font-semibold text-fuchsia-600">
              {barTimeView === 'Día' ? 'Hoy' : barTimeView === 'Mes' ? `${selectedMonth} ${selectedYear}` : `Año ${selectedYear}`}
            </span></span>
            <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-xl p-0.5 ml-2">
              {['Día', 'Mes', 'Año'].map(p => (
                <button key={p} onClick={() => setBarTimeView(p)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${barTimeView === p ? 'bg-fuchsia-500 text-white' : 'text-gray-500 hover:text-gray-800'}`}>
                  {p}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex mb-4 pl-14 pr-2">
          {barIconKeys.map(name => (
            <div key={name} className="flex-1 flex justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d={barIcons[name]} />
              </svg>
            </div>
          ))}
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={barData} margin={{ top: 5, right: 10, left: 10, bottom: 60 }} barCategoryGap="28%">
            <CartesianGrid strokeDasharray="2 4" stroke="#F5D8F5" vertical={false} />
            <XAxis dataKey="name" tick={<BarTick />} axisLine={false} tickLine={false} interval={0} />
            <YAxis domain={[0, 55]} ticks={[0, 15, 30, 45, 60]} tick={{ fontSize: 11, fill: '#4b5563' }} axisLine={false} tickLine={false}
              label={{ value: 'Cantidad', angle: -90, position: 'insideLeft', dx: -2, style: { fontSize: 10, fill: '#d946ef', textAnchor: 'middle' } }} />
            <Tooltip formatter={v => [v, 'Cantidad']} contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12, color: '#111827' }} />
            <Bar dataKey="value" radius={[6, 6, 0, 0]} label={{ position: 'top', fontSize: 11, fill: '#374151', fontWeight: 600 }}>
              {barData.map((entry, i) => {
                const limit = barTimeView === 'Día' ? 10 : barTimeView === 'Mes' ? 24 : 38;
                return <Cell key={i} fill={entry.value >= limit ? '#E8B4E8' : '#7BE87B'} />;
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <p className="text-center text-sm font-bold mt-1" style={{ color: '#c026d3' }}>Procesos</p>
        <div className="flex items-center gap-2 mt-3 px-4 py-3 rounded-xl border border-fuchsia-200 bg-fuchsia-50">
          <div className="w-5 h-5 rounded-md shrink-0" style={{ background: '#E8B4E8', border: '1.5px solid #d946ef' }} />
          <p className="text-xs text-fuchsia-700 font-medium">
            Los procesos en <span className="font-bold">rosa</span> superan el límite del período (día ≥ 10 · mes ≥ 24 · año ≥ 38). Pueden requerir atención de capacidad.
          </p>
        </div>
      </Card>
    </div>
  );
}