import React, { useState, useEffect } from 'react';
import { blockInput } from '../../../shared/utils/blockInput';

const MAX_TEXT_LENGTH = 100;

const ProductCategoryForm = ({ productCategory, onSubmit, onCancel, onShowAlert, onShowConfirm, existingCategories = [] }) => {
  const initialData = {
    nombre: blockInput.limitValue(productCategory?.nombre ?? productCategory?.name ?? '', MAX_TEXT_LENGTH),
    descripcion: blockInput.limitValue(productCategory?.descripcion ?? productCategory?.description ?? '', MAX_TEXT_LENGTH),
  };

  const [formData, setFormData] = useState(initialData);
  const [errors, setErrors] = useState({
    nombre: '',
    descripcion: '',
  });
  const [touched, setTouched] = useState({});

  const hasChanges = () => {
    const initialNombre = blockInput.limitValue(productCategory?.nombre ?? productCategory?.name ?? '', MAX_TEXT_LENGTH);
    const initialDescripcion = blockInput.limitValue(productCategory?.descripcion ?? productCategory?.description ?? '', MAX_TEXT_LENGTH);

    return formData.nombre !== initialNombre || formData.descripcion !== initialDescripcion;
  };

  const validateNombre = (value) => {
    if (!value.trim()) return "El nombre es obligatorio";
    if (/\d/.test(value)) return "El nombre no puede contener números";
    if (value.trim().length < 3) return "El nombre debe tener al menos 3 caracteres";
    const currentId = productCategory?.id ?? productCategory?._id ?? productCategory?.id_categoria_producto ?? productCategory?.id_categorias;
    const isDuplicate = existingCategories.some((cat) => {
      const catId = cat.id ?? cat._id ?? cat.id_categoria_producto ?? cat.id_categorias;
      const catName = cat.name ?? cat.nombre ?? '';
      return catName.toLowerCase().trim() === value.trim().toLowerCase() && String(catId) !== String(currentId);
    });
    if (isDuplicate) return "Ya existe una categoría con ese nombre";
    return "";
  };

  const validateDescripcion = (value) => {
    if (!value.trim()) return "La descripción es obligatoria";
    if (value.trim().length < 10) return "La descripción debe tener al menos 10 caracteres";
    return "";
  };

  const validateField = (fieldName, value) => {
    let error = '';
    if (fieldName === 'nombre') error = validateNombre(value);
    if (fieldName === 'descripcion') error = validateDescripcion(value);
    
    setErrors(prev => ({ ...prev, [fieldName]: error }));
    return error;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    const limitedValue = blockInput.limitValue(value, MAX_TEXT_LENGTH);
    setFormData(prev => ({ ...prev, [name]: limitedValue }));
    validateField(name, limitedValue);
  };

  const handleBlur = (field) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    validateField(field, formData[field]);
  };

  const validateForm = () => {
    const nombreError = validateNombre(formData.nombre);
    const descripcionError = validateDescripcion(formData.descripcion);
    
    setErrors({
      nombre: nombreError,
      descripcion: descripcionError,
    });

    setTouched({
      nombre: true,
      descripcion: true
    });

    if (nombreError || descripcionError) {
      onShowAlert({
        type: "warning",
        title: "Campos inválidos",
        message: "Corrige los campos marcados antes de continuar"
      });
      return false;
    }
    
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) return;
    
    if (productCategory && !hasChanges()) {
      onShowAlert({
        type: "warning",
        title: "Sin cambios",
        message: "No has realizado ningún cambio para guardar"
      });
      return;
    }
    
    
    onSubmit(formData);
  };

  const handleCancelClick = () => {
    if (!hasChanges()) {
      onCancel();
      return;
    }

    onShowConfirm({
      title: "¿Seguro que deseas cancelar?",
      message: "Los cambios no guardados se perderán.",
      confirmText: "Confirmar",
      cancelText: "Cancelar",
      onConfirm: onCancel
    });
  };

  const handleEscapeKey = (e) => e.key === "Escape" && handleCancelClick();

  useEffect(() => {
    window.addEventListener("keydown", handleEscapeKey);
    return () => window.removeEventListener("keydown", handleEscapeKey);
  }, [handleCancelClick, handleEscapeKey]);

  // ─────────────────────────────────────────────────────────────────────────
  // ESTILOS (alineados con ProductionForm)
  // ─────────────────────────────────────────────────────────────────────────
  const getInputStyle = (field) => {
    const baseStyle = {
      width: '100%',
      padding: '10px 14px',
      border: '1.5px solid #e5e7eb',
      borderRadius: '10px',
      fontSize: '14px',
      outline: 'none',
      background: '#fff',
      transition: 'border-color 0.15s, background-color 0.15s',
    };

    if ((touched[field] || formData[field]) && errors[field]) {
      return {
        ...baseStyle,
        borderColor: '#ff4fd6',
      };
    }
    return baseStyle;
  };

  const labelStyle = {
    display: 'block',
    fontSize: '12px',
    fontWeight: '700',
    color: '#374151',
    marginBottom: '6px',
  };

  const requiredStar = (
    <span style={{ color: '#ff4fd6', marginLeft: '2px' }}>*</span>
  );

  const errorStyle = {
    color: '#ff4fd6',
    fontSize: '11px',
    marginLeft: '4px',
    marginTop: '4px',
    display: 'block',
    fontWeight: '700',
  };

  const sectionTitleStyle = {
    fontSize: 11,
    fontWeight: 700,
    color: '#9ca3af',
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    margin: '0 0 14px',
  };

  return (
    <div style={{ padding: '28px 30px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 22 }}>
        <div style={{ width: 38, height: 38, borderRadius: 10, background: '#ff4fd6', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="3" width="7" height="7" rx="1.5"/>
            <rect x="14" y="3" width="7" height="7" rx="1.5"/>
            <rect x="3" y="14" width="7" height="7" rx="1.5"/>
            <rect x="14" y="14" width="7" height="7" rx="1.5"/>
          </svg>
        </div>
        <div>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 800, color: '#1f2937' }}>
            {productCategory ? 'Editar Categoría' : 'Crear Nueva Categoría'}
          </h2>
          <p style={{ margin: 0, fontSize: 11, color: '#9ca3af' }}>
            {productCategory ? 'Actualiza el nombre o la descripción' : 'Completa todos los campos obligatorios'}
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <p style={sectionTitleStyle}>Información de la categoría</p>

        <div style={{ marginBottom: '20px' }}>
          <label style={labelStyle}>Nombre {requiredStar}</label>
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            onBlur={() => handleBlur('nombre')}
            placeholder="Ej. Camiseta"
            maxLength={MAX_TEXT_LENGTH}
            style={getInputStyle('nombre')}
            onFocus={(e) => !errors.nombre && (e.target.style.borderColor = '#ff4fd6')}
          />
          {(touched.nombre || formData.nombre) && errors.nombre && (
            <span style={errorStyle}>⚠ {errors.nombre}</span>
          )}
        </div>

        <div style={{ marginBottom: '24px' }}>
          <label style={labelStyle}>Descripción {requiredStar}</label>
          <textarea
            name="descripcion"
            value={formData.descripcion}
            onChange={handleChange}
            onBlur={() => handleBlur('descripcion')}
            placeholder="Ej. Un jersey negro de cuello redondo hecho de algodón suave y cómodo"
            maxLength={MAX_TEXT_LENGTH}
            style={{
              ...getInputStyle('descripcion'),
              minHeight: '100px',
              resize: 'vertical',
              fontFamily: 'inherit',
            }}
            onFocus={(e) => !errors.descripcion && (e.target.style.borderColor = '#ff4fd6')}
          />
          {(touched.descripcion || formData.descripcion) && errors.descripcion && (
            <span style={errorStyle}>⚠ {errors.descripcion}</span>
          )}
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', paddingTop: '14px', borderTop: '1px solid #f3f4f6' }}>
          <button
            type="button"
            onClick={handleCancelClick}
            style={{
              padding: '8px 16px',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              background: '#fff',
              fontSize: '13px',
              fontWeight: '600',
              color: '#555',
              cursor: 'pointer',
              transition: 'border-color 0.15s, background 0.15s',
            }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = '#d1d5db'; e.currentTarget.style.background = '#f9fafb'; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#e5e7eb'; e.currentTarget.style.background = '#fff'; }}
          >
            Cancelar
          </button>

          <button
            type="submit"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
              padding: '8px 16px',
              backgroundColor: '#FF4FD6',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontSize: '13px',
              fontWeight: '600',
              cursor: 'pointer',
              boxShadow: '0 2px 8px rgba(255,79,214,0.3)',
              transition: 'background 0.15s, box-shadow 0.15s',
              opacity: (errors.nombre || errors.descripcion) ? 0.7 : 1,
            }}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#e040c0'; e.currentTarget.style.boxShadow = '0 4px 14px rgba(255,79,214,0.4)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = '#FF4FD6'; e.currentTarget.style.boxShadow = '0 2px 8px rgba(255,79,214,0.3)'; }}
            disabled={errors.nombre || errors.descripcion}
          >
            {productCategory ? 'Guardar Categoría' : 'Guardar Categoría'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProductCategoryForm;
